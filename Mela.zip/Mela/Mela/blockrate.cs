﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Mela
{
    public partial class blockrate : Form
    {
        public blockrate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string block = textBox1.Text;
                int srate = int.Parse(textBox2.Text);
                int grate = int.Parse(textBox3.Text);

                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string query = string.Format("insert into Extra values('{0}',{1},{2})",block,srate,grate );
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record submitted ....");
                cn.Close();


            }
            catch (Exception g)
            {

                MessageBox.Show(g.Message);
            }

        }
    }
}
