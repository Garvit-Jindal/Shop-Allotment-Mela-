﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Mela
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int a = 1;
                int no = int.Parse(textBox5.Text);
                int no2 = int.Parse(textBox119.Text);
                int no3 = int.Parse(textBox122.Text);
                int no4 = int.Parse(textBox121.Text);
                string y = textBox120.Text.TrimStart();

                if (no > 0 && no2>0)
                {

                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();

                    string Name = string.Format("  Select * from Electricity where shopnofrom={0} and shopnoto={1} and year='{2}' and storenofrom={3} and storenoto={4}", no,no2,y,no3,no4);
                    SqlCommand cmd = new SqlCommand(Name, cn);
                    SqlDataReader rec = cmd.ExecuteReader();

                    if (rec.Read())
                    {
                        string date1 = string.Format(" {0} ", rec.GetValue(1));
                        dateTimePicker1.Text = date1;

                        string name = string.Format(" {0} ", rec.GetValue(2));
                        textBox1.Text = name + "";

                        string fname = string.Format(" {0} ", rec.GetValue(3));
                        textBox2.Text = fname + "";

                        string add = string.Format(" {0} ", rec.GetValue(4));
                        textBox3.Text = add + "";

                        string date = string.Format(" {0} ", rec.GetValue(5));
                        dateTimePicker2.Text = date;


                        string from = string.Format(" {0} ", rec.GetValue(6));
                        textBox4.Text = from + "";


                        textBox38.Text = string.Format(" {0} ", rec.GetValue(7));
                        //textBox38.Text = to + "";

                        textBox6.Text= string.Format(" {0} ", rec.GetValue(8));

                       
                        textBox11.Text = string.Format(" {0} ", rec.GetValue(9));
                        textBox16.Text = string.Format(" {0} ", rec.GetValue(10));
                        textBox21.Text = string.Format(" {0} ", rec.GetValue(11));
                        textBox26.Text = string.Format(" {0} ", rec.GetValue(12));
                        textBox7.Text = string.Format("  {0} ", rec.GetValue(13));
                        textBox12.Text = string.Format(" {0} ", rec.GetValue(14));
                        textBox17.Text = string.Format(" {0} ", rec.GetValue(15));
                        textBox22.Text = string.Format(" {0} ", rec.GetValue(16));
                        textBox27.Text = string.Format(" {0} ", rec.GetValue(17));
                        textBox8.Text = string.Format(" {0} ", rec.GetValue(18));
                        textBox13.Text = string.Format(" {0} ", rec.GetValue(19));

                        textBox18.Text = string.Format(" {0} ", rec.GetValue(20));
                        textBox23.Text = string.Format(" {0} ", rec.GetValue(21));
                        textBox28.Text = string.Format(" {0} ", rec.GetValue(22));
                        textBox9.Text = string.Format(" {0} ", rec.GetValue(23));
                        textBox14.Text = string.Format(" {0} ", rec.GetValue(24));
                        textBox19.Text = string.Format(" {0} ", rec.GetValue(25));
                        textBox24.Text = string.Format(" {0} ", rec.GetValue(26));
                        textBox29.Text = string.Format(" {0} ", rec.GetValue(27));
                        textBox10.Text = string.Format(" {0} ", rec.GetValue(28));
                        textBox15.Text = string.Format(" {0} ", rec.GetValue(29));

                        textBox20.Text = string.Format(" {0} ", rec.GetValue(30));
                        textBox25.Text = string.Format(" {0} ", rec.GetValue(31));
                        textBox30.Text = string.Format(" {0} ", rec.GetValue(32));
                        textBox43.Text = string.Format(" {0} ", rec.GetValue(33));
                        textBox59.Text = string.Format(" {0} ", rec.GetValue(34));
                        textBox75.Text = string.Format(" {0} ", rec.GetValue(35));
                        textBox91.Text = string.Format(" {0} ", rec.GetValue(36));
                        textBox107.Text = string.Format(" {0} ", rec.GetValue(37));
                        textBox42.Text = string.Format(" {0} ", rec.GetValue(38));
                        textBox58.Text = string.Format(" {0} ", rec.GetValue(39));

                        textBox74.Text = string.Format(" {0} ", rec.GetValue(40));
                        textBox90.Text = string.Format(" {0} ", rec.GetValue(41));
                        textBox106.Text = string.Format("{0} ", rec.GetValue(42));
                        textBox41.Text = string.Format(" {0} ", rec.GetValue(43));
                        textBox57.Text = string.Format(" {0} ", rec.GetValue(44));
                        textBox73.Text = string.Format(" {0} ", rec.GetValue(45));
                        textBox89.Text = string.Format(" {0} ", rec.GetValue(46));
                        textBox105.Text = string.Format(" {0} ", rec.GetValue(47));
                        textBox40.Text = string.Format(" {0} ", rec.GetValue(48));
                        textBox56.Text = string.Format(" {0} ", rec.GetValue(49));

                        textBox72.Text = string.Format(" {0} ", rec.GetValue(50));
                        textBox88.Text = string.Format(" {0} ", rec.GetValue(51));
                        textBox104.Text = string.Format(" {0} ", rec.GetValue(52));
                        textBox39.Text = string.Format(" {0} ", rec.GetValue(53));
                        textBox55.Text = string.Format(" {0} ", rec.GetValue(54));
                        textBox71.Text = string.Format(" {0} ", rec.GetValue(55));
                        textBox87.Text = string.Format(" {0} ", rec.GetValue(56));
                        textBox103.Text = string.Format(" {0} ", rec.GetValue(57));
                        textBox48.Text = string.Format(" {0} ", rec.GetValue(58));
                        textBox64.Text = string.Format(" {0} ", rec.GetValue(59));

                        textBox80.Text = string.Format(" {0} ", rec.GetValue(60));
                        textBox96.Text = string.Format(" {0} ", rec.GetValue(61));
                        textBox112.Text = string.Format(" {0} ", rec.GetValue(62));
                        textBox47.Text = string.Format(" {0} ", rec.GetValue(63));
                        textBox63.Text = string.Format(" {0} ", rec.GetValue(64));
                        textBox79.Text = string.Format(" {0} ", rec.GetValue(65));
                        textBox95.Text = string.Format(" {0} ", rec.GetValue(66));
                        textBox111.Text = string.Format(" {0} ", rec.GetValue(67));
                        textBox46.Text = string.Format(" {0} ", rec.GetValue(68));
                        textBox62.Text = string.Format(" {0} ", rec.GetValue(69));

                        textBox78.Text = string.Format(" {0} ", rec.GetValue(70));
                        textBox94.Text = string.Format(" {0} ", rec.GetValue(71));
                        textBox110.Text = string.Format(" {0} ", rec.GetValue(72));
                        textBox45.Text = string.Format(" {0} ", rec.GetValue(73));
                        textBox61.Text = string.Format(" {0} ", rec.GetValue(74));
                        textBox77.Text = string.Format(" {0} ", rec.GetValue(75));
                        textBox93.Text = string.Format(" {0} ", rec.GetValue(76));
                        textBox109.Text = string.Format(" {0} ", rec.GetValue(77));
                        textBox44.Text = string.Format(" {0} ", rec.GetValue(78));
                        textBox60.Text = string.Format(" {0} ", rec.GetValue(79));

                        textBox76.Text = string.Format(" {0} ", rec.GetValue(80));
                        textBox92.Text = string.Format(" {0} ", rec.GetValue(81));
                        textBox108.Text = string.Format(" {0} ", rec.GetValue(82));
                        textBox53.Text = string.Format("  {0} ", rec.GetValue(83));
                        textBox69.Text = string.Format(" {0} ", rec.GetValue(84));
                        textBox85.Text = string.Format(" {0} ", rec.GetValue(85));
                        textBox101.Text = string.Format(" {0} ", rec.GetValue(86));
                        textBox117.Text = string.Format(" {0} ", rec.GetValue(87));
                        textBox52.Text = string.Format("  {0} ", rec.GetValue(88));
                        textBox68.Text = string.Format(" {0} ", rec.GetValue(89));

                        textBox84.Text = string.Format(" {0} ", rec.GetValue(90));
                        textBox100.Text = string.Format(" {0} ", rec.GetValue(91));
                        textBox116.Text = string.Format(" {0} ", rec.GetValue(92));
                        textBox51.Text = string.Format("  {0} ", rec.GetValue(93));
                        textBox67.Text = string.Format(" {0} ", rec.GetValue(94));
                        textBox83.Text = string.Format(" {0} ", rec.GetValue(95));
                        textBox99.Text = string.Format(" {0} ", rec.GetValue(96));
                        textBox115.Text = string.Format(" {0} ", rec.GetValue(97));
                        textBox50.Text = string.Format("  {0} ", rec.GetValue(98));
                        textBox66.Text = string.Format(" {0} ", rec.GetValue(99));

                        textBox82.Text = string.Format(" {0} ", rec.GetValue(100));
                        textBox98.Text = string.Format(" {0} ", rec.GetValue(101));
                        textBox114.Text = string.Format(" {0} ", rec.GetValue(102));
                        textBox49.Text = string.Format("  {0} ", rec.GetValue(103));
                        textBox65.Text = string.Format(" {0} ", rec.GetValue(104));
                        textBox81.Text = string.Format(" {0} ", rec.GetValue(105));
                        textBox97.Text = string.Format(" {0} ", rec.GetValue(106));
                        textBox113.Text = string.Format(" {0} ", rec.GetValue(107));
                        textBox54.Text = string.Format("  {0} ", rec.GetValue(108));
                        textBox70.Text = string.Format(" {0} ", rec.GetValue(109));

                        textBox86.Text = string.Format(" {0} ", rec.GetValue(110));
                        textBox102.Text = string.Format(" {0} ", rec.GetValue(111));
                        textBox118.Text = string.Format(" {0} ", rec.GetValue(112));

                        textBox31.Text = string.Format("  {0} ", rec.GetValue(113));
                        textBox32.Text = string.Format(" {0} ", rec.GetValue(114));
                        textBox33.Text = string.Format(" {0} ", rec.GetValue(115));
                        textBox34.Text = string.Format(" {0} ", rec.GetValue(116));
                        textBox35.Text = string.Format(" {0} ", rec.GetValue(117));
                        textBox36.Text = string.Format("  {0} ", rec.GetValue(118));
                        textBox37.Text = string.Format(" {0} ", rec.GetValue(119));
                        textBox124.Text = string.Format(" {0} ", rec.GetValue(120));
                        textBox123.Text = string.Format(" {0} ", rec.GetValue(121));
                        a = 0;
                        button7.Enabled = true;
                        button8.Enabled = true;
                        checkBox1.Enabled = false;
                        checkBox2.Enabled = false;
                        checkBox3.Enabled = false;
                        checkBox4.Enabled = false;
                        checkBox5.Enabled = false;
                        checkBox6.Enabled = false;
                        checkBox7.Enabled = false;
                        checkBox8.Enabled = false;
                        checkBox9.Enabled = false;
                        checkBox10.Enabled = false;
                        checkBox11.Enabled = false;
                        checkBox12.Enabled = false;
                        checkBox13.Enabled = false;
                        checkBox14.Enabled = false;
                        checkBox15.Enabled = false;
                        checkBox16.Enabled = false;
                        checkBox17.Enabled = false;
                        checkBox18.Enabled = false;
                        checkBox19.Enabled = false;
                        checkBox20.Enabled = false;
                        checkBox21.Enabled = false;
                    }
                    else if(a==1)
                    {
                        rec.Close();
                        Name = string.Format("  Select name,fname,address,date,shopnofrom,shopnoto,storenofrom,storenoto from Reservation where shopnofrom={0} and shopnoto={1} and year=' {2}' and storenofrom={3} and storenoto={4}", no, no2, y,no3,no4);
                         cmd = new SqlCommand(Name, cn);
                         rec = cmd.ExecuteReader();

                        if (rec.Read())
                        {

                            string name = string.Format(" {0} ", rec.GetValue(0));
                            textBox1.Text = name + "";
                            string fname = string.Format(" {0} ", rec.GetValue(1));
                            textBox2.Text = fname + "";
                            string add = string.Format(" {0} ", rec.GetValue(2));
                            textBox3.Text = add + "";
                            string date = string.Format(" {0} ", rec.GetValue(3));
                            dateTimePicker2.Text = date;


                            string from = string.Format(" {0} ", rec.GetValue(4));
                            textBox4.Text = from + "";


                            string to = string.Format(" {0} ", rec.GetValue(5));
                            textBox38.Text = to + "";
                            int store = int.Parse(string.Format(" {0} ", rec.GetValue(6)));
                            textBox124.Text = store.ToString();
                            int store1 = int.Parse(string.Format(" {0} ", rec.GetValue(7)));
                            textBox123.Text = store1.ToString();
                            button6.Enabled = true;


                        }
                    }
                    else
                    {
                        MessageBox.Show("No Record Found.");
                    }


                }
                else
                {

                }

            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }
        public void show()
        {

















        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox1.Checked == true)
            {
                
                string a = checkBox1.Text;
                int id = 1;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);
                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox11.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox16.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox21.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox11.Text = g.ToString();
                textBox16.Text = g.ToString();
                textBox21.Text = g.ToString();
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox2.Checked == true)
            {

                string a = checkBox2.Text;
                int id = 2;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox12.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox17.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox22.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox12.Text = g.ToString();
                textBox17.Text = g.ToString();
                textBox22.Text = g.ToString();
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox3.Checked == true)
            {

                string a = checkBox3.Text;
                int id = 3;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox13.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox18.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox23.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox13.Text = g.ToString();
                textBox18.Text = g.ToString();
                textBox23.Text = g.ToString();
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox4.Checked == true)
            {

                string a = checkBox4.Text;
                int id = 4;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox14.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox19.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox24.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox14.Text = g.ToString();
                textBox19.Text = g.ToString();
                textBox24.Text = g.ToString();
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox5.Checked == true)
            {

                string a = checkBox5.Text;
                int id = 5;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox15.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox20.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox25.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox15.Text = g.ToString();
                textBox20.Text = g.ToString();
                textBox25.Text = g.ToString();
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox10.Checked == true)
            {

                string a = checkBox10.Text;
                int id = 6;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox59.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox75.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox91.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox59.Text = g.ToString();
                textBox75.Text = g.ToString();
                textBox91.Text = g.ToString();
            }
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox9.Checked == true)
            {

                string a = checkBox9.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox58.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox74.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox90.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox58.Text = g.ToString();
                textBox74.Text = g.ToString();
                textBox90.Text = g.ToString();
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            button5.Enabled = false;
            button4.Enabled = false;
            button6.Enabled = false;
            button7.Enabled = false;
            int a = 0;
            textBox6.Text = a.ToString();
            textBox11.Text = a.ToString();
            textBox16.Text = a.ToString();
            textBox21.Text = a.ToString();
            textBox26.Text = a.ToString();



            textBox7.Text = a.ToString();
            textBox12.Text = a.ToString();
            textBox17.Text = a.ToString();
            textBox22.Text = a.ToString();
            textBox27.Text = a.ToString();


            textBox8.Text = a.ToString();
            textBox13.Text = a.ToString();
            textBox18.Text = a.ToString();
            textBox23.Text = a.ToString();
            textBox28.Text = a.ToString();

            textBox9.Text = a.ToString();
            textBox14.Text = a.ToString();
            textBox19.Text = a.ToString();
            textBox24.Text = a.ToString();
            textBox29.Text = a.ToString();


            textBox10.Text = a.ToString();
            textBox15.Text = a.ToString();
            textBox20.Text = a.ToString();
            textBox25.Text = a.ToString();
            textBox30.Text = a.ToString();


            textBox43.Text = a.ToString();
            textBox59.Text = a.ToString();
            textBox75.Text = a.ToString();
            textBox91.Text = a.ToString();
            textBox107.Text = a.ToString();


            textBox42.Text = a.ToString();
            textBox58.Text = a.ToString();
            textBox74.Text = a.ToString();
            textBox90.Text = a.ToString();
            textBox106.Text = a.ToString();


            textBox41.Text = a.ToString();
            textBox57.Text = a.ToString();
            textBox73.Text = a.ToString();
            textBox89.Text = a.ToString();
            textBox105.Text = a.ToString();


            textBox40.Text = a.ToString();
            textBox56.Text = a.ToString();
            textBox72.Text = a.ToString();
            textBox88.Text = a.ToString();
            textBox104.Text = a.ToString();


            textBox39.Text = a.ToString();
            textBox55.Text = a.ToString();
            textBox71.Text = a.ToString();
            textBox87.Text = a.ToString();
            textBox103.Text = a.ToString();


            textBox48.Text = a.ToString();
            textBox64.Text = a.ToString();
            textBox80.Text = a.ToString();
            textBox96.Text = a.ToString();
            textBox112.Text = a.ToString();



            textBox47.Text = a.ToString();
            textBox63.Text = a.ToString();
            textBox79.Text = a.ToString();
            textBox95.Text = a.ToString();
            textBox111.Text = a.ToString();

            textBox46.Text = a.ToString();
            textBox62.Text = a.ToString();
            textBox78.Text = a.ToString();
            textBox94.Text = a.ToString();
            textBox110.Text = a.ToString();


            textBox45.Text = a.ToString();
            textBox61.Text = a.ToString();
            textBox77.Text = a.ToString();
            textBox93.Text = a.ToString();
            textBox109.Text = a.ToString();

            textBox44.Text = a.ToString();
            textBox60.Text = a.ToString();
            textBox76.Text = a.ToString();
            textBox92.Text = a.ToString();
            textBox108.Text = a.ToString();

            textBox53.Text = a.ToString();
            textBox69.Text = a.ToString();
            textBox85.Text = a.ToString();
            textBox101.Text = a.ToString();
            textBox117.Text = a.ToString();


            textBox52.Text = a.ToString();
            textBox68.Text = a.ToString();
            textBox84.Text = a.ToString();
            textBox100.Text = a.ToString();
            textBox116.Text = a.ToString();



            textBox51.Text = a.ToString();
            textBox67.Text = a.ToString();
            textBox83.Text = a.ToString();
            textBox99.Text = a.ToString();
            textBox115.Text = a.ToString();



            textBox50.Text = a.ToString();
            textBox66.Text = a.ToString();
            textBox82.Text = a.ToString();
            textBox98.Text = a.ToString();
            textBox114.Text = a.ToString();


            textBox49.Text = a.ToString();
            textBox65.Text = a.ToString();
            textBox81.Text = a.ToString();
            textBox97.Text = a.ToString();
            textBox113.Text = a.ToString();


            textBox54.Text = a.ToString();
            textBox70.Text = a.ToString();
            textBox86.Text = a.ToString();
            textBox102.Text = a.ToString();
            textBox118.Text = a.ToString();
            textBox122.Text = a.ToString();
            textBox121.Text = a.ToString();
            textBox37.Text = a.ToString();

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

            int g = 0;
            if (checkBox8.Checked == true)
            {

                string a = checkBox8.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox57.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox73.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox89.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox57.Text = g.ToString();
                textBox73.Text = g.ToString();
                textBox89.Text = g.ToString();
            }

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

            int g = 0;
            if (checkBox7.Checked == true)
            {

                string a = checkBox7.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox56.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox72.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox88.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox56.Text = g.ToString();
                textBox72.Text = g.ToString();
                textBox88.Text = g.ToString();
            }



        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox6.Checked == true)
            {

                string a = checkBox6.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox55.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox71.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox87.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox55.Text = g.ToString();
                textBox71.Text = g.ToString();
                textBox87.Text = g.ToString();
            }

        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox15.Checked == true)
            {

                string a = checkBox15.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox64.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox80.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox96.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox64.Text = g.ToString();
                textBox80.Text = g.ToString();
                textBox96.Text = g.ToString();
            }
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox14.Checked == true)
            {

                string a = checkBox14.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox63.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox79.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox95.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox63.Text = g.ToString();
                textBox79.Text = g.ToString();
                textBox95.Text = g.ToString();
            }
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox13.Checked == true)
            {

                string a = checkBox13.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox62.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox78.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox94.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox62.Text = g.ToString();
                textBox78.Text = g.ToString();
                textBox94.Text = g.ToString();
            }
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox12.Checked == true)
            {

                string a = checkBox12.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox61.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox77.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox93.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox61.Text = g.ToString();
                textBox77.Text = g.ToString();
                textBox93.Text = g.ToString();
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox11.Checked == true)
            {

                string a = checkBox11.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox60.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox76.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox92.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox60.Text = g.ToString();
                textBox76.Text = g.ToString();
                textBox92.Text = g.ToString();
            }
        }

        private void checkBox20_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox20.Checked == true)
            {

                string a = checkBox20.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox69.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox85.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox101.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox69.Text = g.ToString();
                textBox85.Text = g.ToString();
                textBox101.Text = g.ToString();
            }
        }

        private void checkBox19_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox19.Checked == true)
            {

                string a = checkBox19.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox68.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox84.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox100.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox68.Text = g.ToString();
                textBox84.Text = g.ToString();
                textBox100.Text = g.ToString();
            }
        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox18.Checked == true)
            {

                string a = checkBox18.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox67.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox83.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox99.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox67.Text = g.ToString();
                textBox83.Text = g.ToString();
                textBox99.Text = g.ToString();
            }
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox17.Checked == true)
            {

                string a = checkBox17.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox66.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox82.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox98.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox66.Text = g.ToString();
                textBox82.Text = g.ToString();
                textBox98.Text = g.ToString();
            }
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox16.Checked == true)
            {

                string a = checkBox16.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox65.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox81.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox97.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox65.Text = g.ToString();
                textBox81.Text = g.ToString();
                textBox97.Text = g.ToString();
            }
        }

        private void checkBox21_CheckedChanged(object sender, EventArgs e)
        {
            int g = 0;
            if (checkBox21.Checked == true)
            {

                string a = checkBox21.Text;
                int id = 7;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("Select fitting,maintainance,jma from Electricity1 where name=N'{0}'", a);

                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {

                    int fit = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox70.Text = fit.ToString();
                    int m = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox86.Text = m.ToString();
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                    textBox102.Text = j.ToString();

                    rec.Close();
                }

            }
            else
            {
                textBox70.Text = g.ToString();
                textBox86.Text = g.ToString();
                textBox102.Text = g.ToString();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("are you sure ??", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {


                int a = int.Parse(textBox6.Text);
                int b = int.Parse(textBox11.Text);
                int c = int.Parse(textBox16.Text);
                int d = int.Parse(textBox21.Text);

                b = a * b;
                textBox11.Text = b.ToString();
                c = c * a;
                textBox16.Text = c.ToString();
                d = d * a;
                textBox21.Text = d.ToString();
                int f = b + c + d;
                textBox26.Text = f.ToString();



                int a1 = int.Parse(textBox7.Text);
                int b1 = int.Parse(textBox12.Text);
                int c1 = int.Parse(textBox17.Text);
                int d1 = int.Parse(textBox22.Text);

                b1 = a1 * b1;
                textBox12.Text = b1.ToString();
                c1 = c1 * a1;
                textBox17.Text = c1.ToString();
                d1 = d1 * a1;
                textBox22.Text = d1.ToString();
                int f1 = b1 + c1 + d1;
                textBox27.Text = f1.ToString();



                int a2 = int.Parse(textBox8.Text);
                int b2 = int.Parse(textBox13.Text);
                int c2 = int.Parse(textBox18.Text);
                int d2 = int.Parse(textBox23.Text);

                b2 = a2 * b2;
                textBox13.Text = b2.ToString();
                c2 = c2 * a2;
                textBox18.Text = c2.ToString();
                d2 = d2 * a2;
                textBox23.Text = d1.ToString();
                int f2 = b2 + c2 + d2;
                textBox28.Text = f2.ToString();


                int a3 = int.Parse(textBox9.Text);
                int b3 = int.Parse(textBox14.Text);
                int c3 = int.Parse(textBox19.Text);
                int d3 = int.Parse(textBox24.Text);

                b3 = a3 * b3;
                textBox14.Text = b3.ToString();
                c3 = c3 * a3;
                textBox19.Text = c3.ToString();
                d3 = d3 * a3;
                textBox24.Text = d3.ToString();
                int f3 = b3 + c3 + d3;
                textBox29.Text = f3.ToString();



                int a4 = int.Parse(textBox10.Text);
                int b4 = int.Parse(textBox15.Text);
                int c4 = int.Parse(textBox20.Text);
                int d4 = int.Parse(textBox25.Text);

                b4 = a4 * b4;
                textBox15.Text = b4.ToString();
                c4 = c4 * a4;
                textBox20.Text = c4.ToString();
                d4 = d4 * a4;
                textBox25.Text = d4.ToString();
                int f4 = b4 + c4 + d4;
                textBox30.Text = f4.ToString();



                int a5 = int.Parse(textBox43.Text);
                int b5 = int.Parse(textBox59.Text);
                int c5 = int.Parse(textBox75.Text);
                int d5 = int.Parse(textBox91.Text);

                b5 = a5 * b5;
                textBox59.Text = b5.ToString();
                c5 = c5 * a5;
                textBox75.Text = c2.ToString();
                d5 = d5 * a5;
                textBox91.Text = d5.ToString();
                int f5 = b5 + c5 + d5;
                textBox107.Text = f5.ToString();



                int a6 = int.Parse(textBox42.Text);
                int b6 = int.Parse(textBox58.Text);
                int c6 = int.Parse(textBox74.Text);
                int d6 = int.Parse(textBox90.Text);

                b6 = a6 * b6;
                textBox58.Text = b6.ToString();
                c6 = c6 * a6;
                textBox74.Text = c6.ToString();
                d6 = d6 * a6;
                textBox90.Text = d6.ToString();
                int f6 = b6 + c6 + d6;
                textBox106.Text = f6.ToString();



                int a7 = int.Parse(textBox41.Text);
                int b7 = int.Parse(textBox57.Text);
                int c7 = int.Parse(textBox73.Text);
                int d7 = int.Parse(textBox89.Text);

                b7 = a7 * b7;
                textBox57.Text = b7.ToString();
                c7 = c7 * a7;
                textBox73.Text = c7.ToString();
                d7 = d7 * a7;
                textBox89.Text = d7.ToString();
                int f7 = b7 + c7 + d7;
                textBox105.Text = f7.ToString();



                int a8 = int.Parse(textBox40.Text);
                int b8 = int.Parse(textBox56.Text);
                int c8 = int.Parse(textBox72.Text);
                int d8 = int.Parse(textBox88.Text);

                b8 = a8 * b8;
                textBox56.Text = b8.ToString();
                c8 = c8 * a8;
                textBox72.Text = c8.ToString();
                d8 = d8 * a8;
                textBox88.Text = d8.ToString();
                int f8 = b8 + c8 + d8;
                textBox104.Text = f8.ToString();


                int a9 = int.Parse(textBox39.Text);
                int b9 = int.Parse(textBox55.Text);
                int c9 = int.Parse(textBox71.Text);
                int d9 = int.Parse(textBox87.Text);

                b9 = a9 * b9;
                textBox55.Text = b9.ToString();
                c9 = c9 * a9;
                textBox71.Text = c9.ToString();
                d9 = d9 * a9;
                textBox87.Text = d9.ToString();
                int f9 = b9 + c9 + d9;
                textBox103.Text = f9.ToString();



                int a10 = int.Parse(textBox48.Text);
                int b10 = int.Parse(textBox64.Text);
                int c10 = int.Parse(textBox80.Text);
                int d10 = int.Parse(textBox96.Text);

                b10 = a10 * b10;
                textBox64.Text = b10.ToString();
                c10 = c10 * a10;
                textBox80.Text = c10.ToString();
                d10 = d10 * a10;
                textBox96.Text = d10.ToString();
                int f10 = b10 + c10 + d10;
                textBox112.Text = f10.ToString();



                int a11 = int.Parse(textBox47.Text);
                int b11 = int.Parse(textBox63.Text);
                int c11 = int.Parse(textBox79.Text);
                int d11 = int.Parse(textBox95.Text);

                b11 = a11 * b11;
                textBox63.Text = b11.ToString();
                c11 = c11 * a11;
                textBox79.Text = c11.ToString();
                d11 = d11 * a11;
                textBox95.Text = d11.ToString();
                int f11 = b11 + c11 + d11;
                textBox111.Text = f11.ToString();


                int a12 = int.Parse(textBox46.Text);
                int b12 = int.Parse(textBox62.Text);
                int c12 = int.Parse(textBox78.Text);
                int d12 = int.Parse(textBox94.Text);

                b12 = a12 * b12;
                textBox62.Text = b12.ToString();
                c12 = c12 * a12;
                textBox78.Text = c12.ToString();
                d12 = d12 * a12;
                textBox94.Text = d12.ToString();
                int f12 = b12 + c12 + d12;
                textBox110.Text = f12.ToString();



                int a13 = int.Parse(textBox45.Text);
                int b13 = int.Parse(textBox61.Text);
                int c13 = int.Parse(textBox77.Text);
                int d13 = int.Parse(textBox93.Text);

                b13 = a13 * b13;
                textBox61.Text = b13.ToString();
                c13 = c13 * a3;
                textBox77.Text = c13.ToString();
                d13 = d13 * a13;
                textBox93.Text = d13.ToString();
                int f13 = b13 + c13 + d13;
                textBox109.Text = f13.ToString();



                int a14 = int.Parse(textBox44.Text);
                int b14 = int.Parse(textBox60.Text);
                int c14 = int.Parse(textBox76.Text);
                int d14 = int.Parse(textBox92.Text);

                b14 = a14 * b14;
                textBox60.Text = b14.ToString();
                c14 = c14 * a14;
                textBox76.Text = c14.ToString();
                d14 = d14 * a14;
                textBox92.Text = d14.ToString();
                int f14 = b14 + c14 + d14;
                textBox108.Text = f14.ToString();


                int a15 = int.Parse(textBox53.Text);
                int b15 = int.Parse(textBox69.Text);
                int c15 = int.Parse(textBox85.Text);
                int d15 = int.Parse(textBox101.Text);

                b15 = a15 * b15;
                textBox69.Text = b15.ToString();
                c15 = c15 * a15;
                textBox85.Text = c15.ToString();
                d15 = d15 * a15;
                textBox101.Text = d15.ToString();
                int f15 = b15 + c15 + d15;
                textBox117.Text = f15.ToString();



                int a16 = int.Parse(textBox52.Text);
                int b16 = int.Parse(textBox68.Text);
                int c16 = int.Parse(textBox84.Text);
                int d16 = int.Parse(textBox100.Text);

                b16 = a16 * b16;
                textBox68.Text = b16.ToString();
                c16 = c16 * a16;
                textBox84.Text = c16.ToString();
                d16 = d16 * a16;
                textBox100.Text = d16.ToString();
                int f16 = b16 + c16 + d16;
                textBox116.Text = f16.ToString();



                int a17 = int.Parse(textBox51.Text);
                int b17 = int.Parse(textBox67.Text);
                int c17 = int.Parse(textBox83.Text);
                int d17 = int.Parse(textBox99.Text);

                b17 = a17 * b17;
                textBox67.Text = b17.ToString();
                c17 = c17 * a17;
                textBox83.Text = c17.ToString();
                d17 = d17 * a17;
                textBox99.Text = d17.ToString();
                int f17 = b17 + c17 + d17;
                textBox115.Text = f17.ToString();


                int a18 = int.Parse(textBox50.Text);
                int b18 = int.Parse(textBox66.Text);
                int c18 = int.Parse(textBox82.Text);
                int d18 = int.Parse(textBox98.Text);

                b18 = a18 * b18;
                textBox66.Text = b18.ToString();
                c18 = c18 * a18;
                textBox82.Text = c18.ToString();
                d18 = d18 * a18;
                textBox98.Text = d18.ToString();
                int f18 = b18 + c18 + d18;
                textBox114.Text = f18.ToString();



                int a19 = int.Parse(textBox49.Text);
                int b19 = int.Parse(textBox65.Text);
                int c19 = int.Parse(textBox81.Text);
                int d19 = int.Parse(textBox97.Text);

                b19 = a19 * b19;
                textBox65.Text = b19.ToString();
                c19 = c19 * a19;
                textBox81.Text = c19.ToString();
                d19 = d19 * a19;
                textBox97.Text = d19.ToString();
                int f19 = b19 + c19 + d19;
                textBox113.Text = f19.ToString();



                int a20 = int.Parse(textBox54.Text);
                int b20 = int.Parse(textBox70.Text);
                int c20 = int.Parse(textBox86.Text);
                int d20 = int.Parse(textBox102.Text);

                b20 = a20 * b20;
                textBox70.Text = b20.ToString();
                c20 = c20 * a20;
                textBox86.Text = c20.ToString();
                d20 = d20 * a20;
                textBox102.Text = d20.ToString();
                int f20 = b20 + c20 + d20;
                textBox118.Text = f20.ToString();



                int t = a + a1 + a2 + a3 + a4 + a5 + a6 + a7 + a8 + a9 + a10 + a11 + a12 + a13 + a14 + a15 + a16 + a17 + a18 + a19 + a20;
                textBox31.Text = t.ToString();

                int t1 = b + b1 + b2 + b3 + b4 + b5 + b6 + b7 + b8 + b9 + b10 + b11 + b12 + b13 + b14 + b15 + b16 + b17 + b18 + b19 + b20;
                textBox32.Text = t1.ToString();

                int t2 = c + c1 + c2 + c3 + c4 + c5 + c6 + c7 + c8 + c9 + c10 + c11 + c12 + c13 + c14 + c15 + c16 + c17 + c18 + c19 + c20;
                textBox33.Text = t2.ToString();

                int t3 = d + d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8 + d9 + d10 + d11 + d12 + d13 + d14 + d15 + d16 + d17 + d18 + d19 + d20;
                textBox34.Text = t3.ToString();

                int t4 = f + f1 + f2 + f3 + f4 + f5 + f6 + f7 + f8 + f9 + f10 + f11 + f12 + f13 + f14 + f15 + f16 + f17 + f18 + f19 + f20;
                textBox35.Text = t4.ToString();

                

                button7.Enabled = true;

            }
            else
            {

                MessageBox.Show("please confirm ");
            }


        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("are you sure ??", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {
                    int t = int.Parse(textBox35.Text);
                   
                    int j = int.Parse(textBox36.Text);

                    int d = int.Parse(textBox37.Text);
                    if (d > 0)
                    {
                        int due = t - j;
                        textBox37.Text = due.ToString();
                        button5.Enabled = false;
                        button4.Enabled = true;
                        MessageBox.Show("Please pay " + due + "rs soon", "Alert");
                    }
                    else
                    {
                        int due = t - j;
                        textBox37.Text = due.ToString();
                        MessageBox.Show("Please pay " + due + "rs soon", "Alert");
                        button5.Enabled = true;
                        button4.Enabled = false;
                    }
                }
            }
            catch (Exception f)
            {

                MessageBox.Show(f.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string date = dateTimePicker1.Text;
                string year = textBox120.Text;
                string name = textBox1.Text;
                string fname = textBox2.Text;
                string add = textBox3.Text;
                string date1 = dateTimePicker2.Text;
                int from = int.Parse(textBox4.Text);
                int to = int.Parse(textBox38.Text);


                int a = int.Parse(textBox6.Text);
                int b = int.Parse(textBox11.Text);
                int c = int.Parse(textBox16.Text);
                int d = int.Parse(textBox21.Text);
                int f = int.Parse(textBox26.Text);



                int a1 = int.Parse(textBox7.Text);
                int b1 = int.Parse(textBox12.Text);
                int c1 = int.Parse(textBox17.Text);
                int d1 = int.Parse(textBox22.Text);
                int f1 = int.Parse(textBox27.Text);




                int a2 = int.Parse(textBox8.Text);
                int b2 = int.Parse(textBox13.Text);
                int c2 = int.Parse(textBox18.Text);
                int d2 = int.Parse(textBox23.Text);
                int f2 = int.Parse(textBox28.Text);



                int a3 = int.Parse(textBox9.Text);
                int b3 = int.Parse(textBox14.Text);
                int c3 = int.Parse(textBox19.Text);
                int d3 = int.Parse(textBox24.Text);
                int f3 = int.Parse(textBox29.Text);




                int a4 = int.Parse(textBox10.Text);
                int b4 = int.Parse(textBox15.Text);
                int c4 = int.Parse(textBox20.Text);
                int d4 = int.Parse(textBox25.Text);
                int f4 = int.Parse(textBox30.Text);




                int a5 = int.Parse(textBox43.Text);
                int b5 = int.Parse(textBox59.Text);
                int c5 = int.Parse(textBox75.Text);
                int d5 = int.Parse(textBox91.Text);
                int f5 = int.Parse(textBox107.Text);



                int a6 = int.Parse(textBox42.Text);
                int b6 = int.Parse(textBox58.Text);
                int c6 = int.Parse(textBox74.Text);
                int d6 = int.Parse(textBox90.Text);
                int f6 = int.Parse(textBox106.Text);


                int a7 = int.Parse(textBox41.Text);
                int b7 = int.Parse(textBox57.Text);
                int c7 = int.Parse(textBox73.Text);
                int d7 = int.Parse(textBox89.Text);
                int f7 = int.Parse(textBox105.Text);


                int a8 = int.Parse(textBox40.Text);
                int b8 = int.Parse(textBox56.Text);
                int c8 = int.Parse(textBox72.Text);
                int d8 = int.Parse(textBox88.Text);
                int f8 = int.Parse(textBox104.Text);


                int a9 = int.Parse(textBox39.Text);
                int b9 = int.Parse(textBox55.Text);
                int c9 = int.Parse(textBox71.Text);
                int d9 = int.Parse(textBox87.Text);
                int f9 = int.Parse(textBox103.Text);



                int a10 = int.Parse(textBox48.Text);
                int b10 = int.Parse(textBox64.Text);
                int c10 = int.Parse(textBox80.Text);
                int d10 = int.Parse(textBox96.Text);
                int f10 = int.Parse(textBox112.Text);



                int a11 = int.Parse(textBox47.Text);
                int b11 = int.Parse(textBox63.Text);
                int c11 = int.Parse(textBox79.Text);
                int d11 = int.Parse(textBox95.Text);
                int f11 = int.Parse(textBox111.Text);



                int a12 = int.Parse(textBox46.Text);
                int b12 = int.Parse(textBox62.Text);
                int c12 = int.Parse(textBox78.Text);
                int d12 = int.Parse(textBox94.Text);
                int f12 = int.Parse(textBox110.Text);



                int a13 = int.Parse(textBox45.Text);
                int b13 = int.Parse(textBox61.Text);
                int c13 = int.Parse(textBox77.Text);
                int d13 = int.Parse(textBox93.Text);
                int f13 = int.Parse(textBox109.Text);




                int a14 = int.Parse(textBox44.Text);
                int b14 = int.Parse(textBox60.Text);
                int c14 = int.Parse(textBox76.Text);
                int d14 = int.Parse(textBox92.Text);
                int f14 = int.Parse(textBox108.Text);



                int a15 = int.Parse(textBox53.Text);
                int b15 = int.Parse(textBox69.Text);
                int c15 = int.Parse(textBox85.Text);
                int d15 = int.Parse(textBox101.Text);
                int f15 = int.Parse(textBox117.Text);


                int a16 = int.Parse(textBox52.Text);
                int b16 = int.Parse(textBox68.Text);
                int c16 = int.Parse(textBox84.Text);
                int d16 = int.Parse(textBox100.Text);
                int f16 = int.Parse(textBox116.Text);




                int a17 = int.Parse(textBox51.Text);
                int b17 = int.Parse(textBox67.Text);
                int c17 = int.Parse(textBox83.Text);
                int d17 = int.Parse(textBox99.Text);
                int f17 = int.Parse(textBox115.Text);



                int a18 = int.Parse(textBox50.Text);
                int b18 = int.Parse(textBox66.Text);
                int c18 = int.Parse(textBox82.Text);
                int d18 = int.Parse(textBox98.Text);
                int f18 = int.Parse(textBox114.Text);


                int a19 = int.Parse(textBox49.Text);
                int b19 = int.Parse(textBox65.Text);
                int c19 = int.Parse(textBox81.Text);
                int d19 = int.Parse(textBox97.Text);
                int f19 = int.Parse(textBox113.Text);




                int a20 = int.Parse(textBox54.Text);
                int b20 = int.Parse(textBox70.Text);
                int c20 = int.Parse(textBox86.Text);
                int d20 = int.Parse(textBox102.Text);
                int f20 = int.Parse(textBox118.Text);

                int no = int.Parse(textBox31.Text);
                int fit = int.Parse(textBox32.Text);
                int main = int.Parse(textBox33.Text);
                int dep = int.Parse(textBox34.Text);
                int tot = int.Parse(textBox35.Text);

                int paid = int.Parse(textBox36.Text);
                int due = int.Parse(textBox37.Text);
                int store = int.Parse(textBox124.Text);
                int store1 = int.Parse(textBox123.Text);
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string query = string.Format("insert into Electricity values('{0}','{1}',N'{2}','{3}','{4}','{5}',{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},{28},{29},{30},{31},{32},{33},{34},{35},{36},{37},{38},{39},{40},{41},{42},{43},{44},{45},{46},{47},{48},{49},{50},{51},{52},{53},{54},{55},{56},{57},{58},{59},{60},{61},{62},{63},{64},{65},{66},{67},{68},{69},{70},{71},{72},{73},{74},{75},{76},{77},{78},{79},{80},{81},{82},{83},{84},{85},{86},{87},{88},{89},{90},{91},{92},{93},{94},{95},{96},{97},{98},{99},{100},{101},{102},{103},{104},{105},{106},{107},{108},{109},{110},{111},{112},{113},{114},{115},{116},{117},{118},{119},{120},{121})",year,date,name,fname,add,date1,from,to,a,b,c,d,f,a1,b1,c1,d1,f1,a2,b2,c2,d2,f2,a3,b3,c3,d3,f3,a4,b4,c4,d4,f4,a5,b5,c5,d5,f5,a6,b6,c6,d6,f6,a7,b7,c7,d7,f7,a8, b8, c8, d8, f8, a9, b9, c9, d9, f9, a10, b10, c10, d10, f10, a11, b11, c11, d11, f11, a12, b12, c12, d12, f12, a13, b13, c13, d13, f13, a14, b14, c14, d14, f14, a15, b15, c15, d15, f15, a16, b16, c16, d16, f16, a17, b17, c17, d17, f17, a18, b18, c18, d18, f18, a19, b19, c19, d19, f19, a20, b20, c20, d20, f20,no,fit,main,dep,tot,paid,due,store,store1);
                
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Submitted");

                button8.Enabled = true;
            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);

            }


            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int paid = int.Parse(textBox36.Text);
                int due = int.Parse(textBox37.Text);
                int from = int.Parse(textBox4.Text);
                int to = int.Parse(textBox38.Text);
                string year = textBox120.Text;

                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string query = string.Format("update Electricity set paid={0} ,due={1} where shopnofrom={2} and shopnoto={3} and year='{4}'", paid, due,from,to,year);

                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record updated");


            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;
        private void PrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }
        private void button8_Click(object sender, EventArgs e)
        {
            PrintScreen();
            printPreviewDialog1.ShowDialog();
        }

        private void textBox37_TextChanged(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void textBox36_TextChanged(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label40_Click(object sender, EventArgs e)
        {

        }

        private void label48_Click(object sender, EventArgs e)
        {

        }

        private void textBox123_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox124_TextChanged(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void label47_Click(object sender, EventArgs e)
        {

        }

        private void textBox121_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox122_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label42_Click(object sender, EventArgs e)
        {

        }

        private void label43_Click(object sender, EventArgs e)
        {

        }

        private void label44_Click(object sender, EventArgs e)
        {

        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void label46_Click(object sender, EventArgs e)
        {

        }

        private void textBox120_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox119_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox38_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
