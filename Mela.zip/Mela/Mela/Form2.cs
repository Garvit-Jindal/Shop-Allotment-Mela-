﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Drawing.Printing;

namespace Mela
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               
                string year = textBox1.Text;
                int sfrom = Int32.Parse(textBox2.Text);
                int sto = Int32.Parse(textBox3.Text);
                int no = Int32.Parse(textBox4.Text);
                string block = textBox5.Text;
                string name = textBox6.Text;
                string fname = textBox7.Text;
                string add = textBox8.Text;
                double mob = double.Parse(textBox9.Text);
                string cat = "";
                 if (radioButton1.Checked==true)
                 {
                     cat = "Garments";
                 }
                else if (radioButton2.Checked == true)
                 {
                      cat = "toys";
                 }
                 if (radioButton3.Checked == true)
                 {
                      cat = "food";
                 }
                 if (radioButton4.Checked == true)
                 {
                      cat = "dress";
                 }
                 if (radioButton5.Checked == true)
                 {
                      cat = "electronics";
                 }
                 if (radioButton6.Checked == true)
                 {
                      cat = "gifts";
                 }
               // string cat = "gifts";
                string pan = textBox10.Text;
                string type = textBox11.Text;
                int from = int.Parse(textBox19.Text);
                int to = int.Parse(textBox18.Text);
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                OpenFileDialog openFd = new OpenFileDialog();
                openFd.Filter = "Images only. |*.jpg;*.png;";
                if (openFd.ShowDialog() == DialogResult.OK)
                {
                    pictureBox1.Image = Image.FromFile(openFd.FileName);
                    Image img = Image.FromFile(openFd.FileName);
                    MemoryStream ms = new MemoryStream();
                    if (MessageBox.Show("are you sure ??", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        img.Save(ms, img.RawFormat);
                        PracticeEntities pt = new PracticeEntities();
                        pt.pics.Add(new pic() { image = ms.ToArray() });
                        pt.SaveChanges();
                        MessageBox.Show("image stored..");

                        string query = string.Format("insert into Registration values('{0}',{1},{2},{3},'{4}',N'{5}',N'{6}',N'{7}',{8},'{9}','{10}','{11}',{12},{13})", year, sfrom, sto, no, block, name, fname, add, mob, cat, pan, type,from,to);
                        
                        SqlCommand cmd = new SqlCommand(query, cn);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record submitted ....");
                        button3.Enabled = true;
                        cn.Close();
                    }
                    else
                    {
                        MessageBox.Show("Try again ");
                    }
                }

            } catch (Exception t)
            {
                MessageBox.Show(t.Message);
            }
        }

       
        private void Form2_Load(object sender, EventArgs e)
        {
            int a = 0;
            textBox16.Text = a.ToString();
            textBox17.Text = a.ToString();
            textBox18.Text = a.ToString();
            textBox19.Text = a.ToString();



            button3.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
                OpenFileDialog openFd = new OpenFileDialog();
            openFd.Filter = "Images only. |*.jpg;*.png;";
            if (openFd.ShowDialog() == DialogResult.OK)
            {
                if (MessageBox.Show("are you sure ??", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {
                    pictureBox1.Image = Image.FromFile(openFd.FileName);
                Image img = Image.FromFile(openFd.FileName);
                MemoryStream ms = new MemoryStream();
                img.Save(ms, img.RawFormat);
                    PracticeEntities pt = new PracticeEntities();
                    pt.pics.Add(new pic() { image = ms.ToArray() });
                    pt.SaveChanges();
                    MessageBox.Show("image stored..");
                }
                else
                {
                    MessageBox.Show("image not stored..");
                }
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (MessageBox.Show("Do you really want to exit??", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                Form2 f1 = new Form2();
                f1.Close();

            }

            else
            {
                e.Cancel = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                int no = int.Parse(textBox12.Text);
                int no2 = int.Parse(textBox13.Text);
                int no4 = int.Parse(textBox17.Text);
                int no5 = int.Parse(textBox16.Text);
                string year = textBox14.Text;
                if (no > 0 && no2 > 0)
                {
                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();
                    string Name = string.Format("Select year,shopnofrom,shopnoto,noofshops,blockno,name,fname,address,mobile,category,proof,type,id,storenofrom,storenoto from Registration where shopnofrom={0} and shopnoto={1} and year='{2}' and storenofrom={3} and storenoto={4}", no, no2,year,no4,no5);
                    SqlCommand cmd = new SqlCommand(Name, cn);
                    SqlDataReader rec = cmd.ExecuteReader();

                    if (rec.Read())
                    {
                        button1.Enabled = false;
                        button3.Enabled = true;
                        string Year = string.Format(" {0} ", rec.GetValue(0));
                        textBox1.Text = Year + "";

                        string from = string.Format(" {0} ", rec.GetValue(1));
                        textBox2.Text = from + "";

                        string to = string.Format(" {0} ", rec.GetValue(2));
                        textBox3.Text = to + "";

                        string no3 = string.Format(" {0} ", rec.GetValue(3));
                        textBox4.Text = no3 + "";

                        string block = string.Format(" {0} ", rec.GetValue(4));
                        textBox5.Text = block + "";

                        string name = string.Format(" {0} ", rec.GetValue(5));
                        textBox6.Text = name + "";

                        string fname = string.Format(" {0} ", rec.GetValue(6));
                        textBox7.Text = fname + "";

                        string add = string.Format(" {0} ", rec.GetValue(7));
                        textBox8.Text = add + "";

                        string mob = string.Format(" {0} ", rec.GetValue(8));
                        textBox9.Text = mob + "";

                        string cat = string.Format(" {0} ", rec.GetValue(9));

                        textBox15.Text = cat;
                        
                        if (radioButton1.Text==cat)
                        {
                            radioButton1.Checked = true;

                        }

                        if (radioButton2.Text==cat)
                        {
                            radioButton2.Checked = true;

                        }

                        if (cat == "food")
                        {
                            radioButton3.Checked = true;

                        }

                        if (radioButton4.Text == cat)
                        {
                            radioButton4.Checked = true;

                        }

                        if (cat == "electronics")
                        {
                            radioButton5.Checked = true;

                        }
                        if (cat == "gifts")
                        {
                            radioButton6.Checked = true;

                        }

                        string prof = string.Format(" {0} ", rec.GetValue(10));
                        textBox10.Text = prof + "";

                        string type = string.Format(" {0} ", rec.GetValue(11));
                        textBox11.Text = type + "";
                       

                        int id  = int.Parse(string.Format(" {0} ", rec.GetValue(12)));
                        textBox19.Text= string.Format(" {0} ", rec.GetValue(13));
                        textBox18.Text = string.Format(" {0} ", rec.GetValue(14));
                        cn.Close();
                        rec.Close();

                        cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                        cn.Open();
                        MemoryStream stream = new MemoryStream();
                        

                         Name = string.Format("  Select image from pic where id={0} ", id);
                         cmd = new SqlCommand(Name, cn);
                        byte[] image = (byte[])cmd.ExecuteScalar();
                        stream.Write(image, 0, image.Length);
                        cn.Close();
                        Bitmap bitmap = new Bitmap(stream);
                        pictureBox1.Image = bitmap;

                    }


                    else
                    {
                        MessageBox.Show("No Record Found.");
                    }
                }
                else
                { }
            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);

            }
            }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        

        private void button3_Click_1(object sender, EventArgs e)
        {
            PrintScreen();
            printPreviewDialog1.ShowDialog();
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;

        private void PrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }
    }
}
