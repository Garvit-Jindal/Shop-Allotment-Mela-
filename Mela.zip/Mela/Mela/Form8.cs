﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                int no = int.Parse(textBox11.Text);
                int no1= int.Parse(textBox12.Text);
                int no3 = int.Parse(textBox30.Text);
                int no4 = int.Parse(textBox29.Text);
                string y = textBox13.Text;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("  Select name,fname,address,shopnofrom,shopnoto,block,year,reservation,rent,charge50,charge15,lastyear,charge25,other,coveredcharge,paidreservation,paidrent,paidcharge50,paidcharge15,paidlastyear,paidcharge25,paidother,paidcoveredcharge,storenofrom,storenoto from Reservation where shopnofrom={0} and shopnoto={1} and year=' {2}' and storenofrom={3} and storenoto={4} ", no, no1, y,no3,no4);
                SqlCommand cmd = new SqlCommand(Name, cn);

                SqlDataReader rec = cmd.ExecuteReader();


                if (rec.Read())
                {
                    

                    string name = string.Format(" {0} ", rec.GetValue(0));
                    textBox1.Text = name + "";

                    string fname = string.Format(" {0} ", rec.GetValue(1));
                    textBox2.Text = fname + "";

                    string add = string.Format(" {0} ", rec.GetValue(2));
                    textBox3.Text = add + "";

                    string from = string.Format(" {0} ", rec.GetValue(3));
                    textBox4.Text = from + "";

                    string to = string.Format(" {0} ", rec.GetValue(4));
                    textBox5.Text = to + "";

                    string block = string.Format(" {0} ", rec.GetValue(5));
                    textBox6.Text = block + "";

                    string year = string.Format(" {0} ", rec.GetValue(6));
                    textBox7.Text = year + "";

                    int a = int.Parse(string.Format(" {0} ", rec.GetValue(7)));
                    int b = int.Parse(string.Format(" {0} ", rec.GetValue(8)));
                    int c = int.Parse(string.Format(" {0} ", rec.GetValue(9)));
                    int d = a + b + c;
                    textBox8.Text = d.ToString();
                    int f = int.Parse(string.Format(" {0} ", rec.GetValue(10)));
                    textBox9.Text = f.ToString();
                    int g = d + f;
                    textBox10.Text = g.ToString();

                    int h = int.Parse(string.Format(" {0} ", rec.GetValue(11)));
                    int i = int.Parse(string.Format(" {0} ", rec.GetValue(12)));
                    int j = int.Parse(string.Format(" {0} ", rec.GetValue(13)));
                    int k = h + i + j;
                    textBox16.Text = k.ToString();
                    int l = int.Parse(string.Format(" {0} ", rec.GetValue(14)));
                    textBox15.Text = l.ToString();
                    int m = k + l;
                    textBox14.Text = m.ToString();
                    int n = int.Parse(string.Format(" {0} ", rec.GetValue(15)));
                    int o = int.Parse(string.Format(" {0} ", rec.GetValue(16)));
                    int p = int.Parse(string.Format(" {0} ", rec.GetValue(17)));
                    int r = int.Parse(string.Format(" {0} ", rec.GetValue(18)));
                    int q = n + o + p + r;
                    textBox24.Text = q.ToString();

                    int n1 = int.Parse(string.Format(" {0} ", rec.GetValue(19)));
                    int o1 = int.Parse(string.Format(" {0} ", rec.GetValue(20)));
                    int p1 = int.Parse(string.Format(" {0} ", rec.GetValue(21)));
                    int r1 = int.Parse(string.Format(" {0} ", rec.GetValue(22)));
                    int q1 = n1 + o1 + p1 + r1;
                    textBox25.Text = q1.ToString();
                    button4.Enabled = true;
                    int store = int.Parse(string.Format(" {0} ", rec.GetValue(23)));
                    textBox32.Text = store.ToString();
                    int store1 = int.Parse(string.Format(" {0} ", rec.GetValue(24)));
                    textBox31.Text = store1.ToString();

                    rec.Close();
                }

                Name = string.Format("  Select fulltotal,paidtotal from Extraarea where shopnofrom={0} and shopnoto={1} and year='  {2}' and storenofrom={3} and storenoto={4} ", no, no1, y,no3,no4);
                cmd = new SqlCommand(Name, cn);

                rec = cmd.ExecuteReader();


                if (rec.Read())
                {


                    int area = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox20.Text = area.ToString();
                    textBox18.Text = area.ToString();
                    int paid = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox26.Text = paid.ToString();
                    rec.Close();

                }
                else
                {
                    MessageBox.Show("you have not filled atirikt area");
                    int a = 0;
                    textBox20.Text = a.ToString();
                    textBox18.Text = a.ToString();
                    textBox26.Text = a.ToString();
                    rec.Close();

                }

                Name = string.Format("  Select ttot,paid  from Electricity where shopnofrom={0} and shopnoto={1} and year='{2}' and storenofrom={3} and storenoto={4} ", no, no1, y,no3,no4);
                cmd = new SqlCommand(Name, cn);

                rec = cmd.ExecuteReader();


                if (rec.Read())
                {
                    int a = 0;

                    int tot = int.Parse(string.Format(" {0} ", rec.GetValue(0)));
                    textBox19.Text = tot.ToString();
                   
                    int paid = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                    textBox27.Text = paid.ToString();
                    textBox21.Text = a.ToString();
                    textBox21.Enabled = false;
                    textBox22.Enabled = false;
                    textBox17.Text = tot.ToString();
                    textBox27.Text = paid.ToString();
                    rec.Close();

                }



            }
            catch (Exception g)
            {


            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                int a1 = 0;
                int f = int.Parse(textBox19.Text);

                if (checkBox1.Checked == true)
                {
                    textBox21.Enabled = true;
                    textBox22.Enabled = true;


                }
                else

                {
                    textBox21.Enabled = false;
                    textBox22.Enabled = false;
                    textBox21.Text = a1.ToString();
                    textBox22.Text = a1.ToString();
                    textBox17.Text = f.ToString();
                }
            }
            catch (Exception g)
            {

          }
        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int a1 = 0;
                int a = int.Parse(textBox19.Text);
                int b = int.Parse(textBox22.Text);
                int f = int.Parse(textBox19.Text);

                if (checkBox1.Checked == true)
                {
                    int c = a * b;
                    int d = c / 100;
                    textBox21.Text = d.ToString();

                    int g = f + d;
                    textBox17.Text = g.ToString();
                }
                
            }
            catch (Exception g)
            {
                
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(textBox10.Text);
                int b = int.Parse(textBox14.Text);
                int c = int.Parse(textBox18.Text);
                int d = int.Parse(textBox17.Text);
                int f = a + b + c + d;
                textBox23.Text = f.ToString();

                int a1 = int.Parse(textBox24.Text);
                int b1 = int.Parse(textBox25.Text);
                int c1 = int.Parse(textBox26.Text);
                int d1 = int.Parse(textBox27.Text);
                int f1 = a1 + b1 + c1 + d1;
                textBox28.Text = f1.ToString();
                if (f == f1)
                {
                    button1.Enabled = true;
                }
                else
                {

                    MessageBox.Show("please pay rest money before issuing no dues");
                }

            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            button1.Enabled = false;
            button4.Enabled = false;
            int a = 0;
            textBox22.Text = a.ToString();
            textBox29.Text = a.ToString();
            textBox30.Text = a.ToString();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;
        private void PrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                PrintScreen();
                printPreviewDialog1.ShowDialog();

                string date = dateTimePicker1.Text;
                string name = textBox1.Text;
                string fname = textBox2.Text;
                string add = textBox3.Text;
                int from = int.Parse(textBox4.Text);
                int to = int.Parse(textBox5.Text);
                string block = textBox6.Text;
                string year = textBox7.Text;
                int res = int.Parse(textBox8.Text);
                int res15 = int.Parse(textBox9.Text);
                int rest = int.Parse(textBox10.Text);
                int resp = int.Parse(textBox24.Text);
                int cov = int.Parse(textBox16.Text);
                int cov15 = int.Parse(textBox15.Text);
                int covt = int.Parse(textBox14.Text);
                int covp = int.Parse(textBox25.Text);
                int extra = int.Parse(textBox20.Text);
                int extrat = int.Parse(textBox18.Text);
                int extrap = int.Parse(textBox26.Text);
                int ele = int.Parse(textBox19.Text);
                int eleper = int.Parse(textBox22.Text);
                int eleper1 = int.Parse(textBox21.Text);
                int elet = int.Parse(textBox17.Text);
                int elep = int.Parse(textBox27.Text);
                int total = int.Parse(textBox23.Text);
                int paid = int.Parse(textBox28.Text);
                int store = int.Parse(textBox32.Text);
                int store1 = int.Parse(textBox31.Text);

                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string query = string.Format("insert into Nodues values('{0}',N'{1}','{2}','{3}',{4},{5},'{6}','{7}',{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27})",date,name,fname,add,from,to,block,year,res,res15,rest,resp,cov,cov15,covt,covp,extra,extrat,extrap,ele,eleper,eleper1,elet,elep,total,paid,store,store1);
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record submitted ....");
                cn.Close();















            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);

            }
            
            
        }
    }
}
