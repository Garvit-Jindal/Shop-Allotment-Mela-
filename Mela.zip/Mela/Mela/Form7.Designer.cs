﻿namespace Mela
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox113 = new System.Windows.Forms.TextBox();
            this.textBox114 = new System.Windows.Forms.TextBox();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.textBox116 = new System.Windows.Forms.TextBox();
            this.textBox117 = new System.Windows.Forms.TextBox();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.textBox109 = new System.Windows.Forms.TextBox();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox112 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox119 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox120 = new System.Windows.Forms.TextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.button8 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox122 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox123 = new System.Windows.Forms.TextBox();
            this.textBox124 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(332, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 46);
            this.label1.TabIndex = 0;
            this.label1.Text = "बिजली किराया";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(623, 132);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(188, 20);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "1. दुकानदार का नाम";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Kruti Dev 010", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(165, 183);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(266, 31);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(449, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "पिता का नाम";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Kruti Dev 010", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(552, 183);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(229, 31);
            this.textBox2.TabIndex = 5;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "२. पूर्ण स्थायी पता";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Font = new System.Drawing.Font("Kruti Dev 010", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(165, 220);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(616, 32);
            this.textBox3.TabIndex = 7;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(140, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "3. अलॉटमेंट दिनांक";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(164, 258);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(188, 20);
            this.dateTimePicker2.TabIndex = 9;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(21, 281);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(176, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "4. दुकान/चबूतरा क्रमांक:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Location = new System.Drawing.Point(191, 287);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(59, 20);
            this.textBox4.TabIndex = 11;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Location = new System.Drawing.Point(96, 127);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(57, 20);
            this.textBox5.TabIndex = 15;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(431, 121);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 38);
            this.button1.TabIndex = 16;
            this.button1.Text = "खोजें";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Location = new System.Drawing.Point(8, 336);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(807, 276);
            this.panel1.TabIndex = 17;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel10.Location = new System.Drawing.Point(256, -12);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(505, 10);
            this.panel10.TabIndex = 14;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel11.Location = new System.Drawing.Point(768, -12);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(228, 10);
            this.panel11.TabIndex = 15;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.checkBox21);
            this.panel2.Controls.Add(this.checkBox16);
            this.panel2.Controls.Add(this.checkBox17);
            this.panel2.Controls.Add(this.checkBox18);
            this.panel2.Controls.Add(this.checkBox19);
            this.panel2.Controls.Add(this.checkBox20);
            this.panel2.Controls.Add(this.checkBox11);
            this.panel2.Controls.Add(this.checkBox12);
            this.panel2.Controls.Add(this.checkBox13);
            this.panel2.Controls.Add(this.checkBox14);
            this.panel2.Controls.Add(this.checkBox15);
            this.panel2.Controls.Add(this.checkBox6);
            this.panel2.Controls.Add(this.checkBox7);
            this.panel2.Controls.Add(this.checkBox8);
            this.panel2.Controls.Add(this.checkBox9);
            this.panel2.Controls.Add(this.checkBox10);
            this.panel2.Controls.Add(this.checkBox5);
            this.panel2.Controls.Add(this.checkBox4);
            this.panel2.Controls.Add(this.checkBox3);
            this.panel2.Controls.Add(this.checkBox2);
            this.panel2.Controls.Add(this.checkBox1);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(40, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(329, 724);
            this.panel2.TabIndex = 17;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox21.Location = new System.Drawing.Point(232, 689);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(89, 28);
            this.checkBox21.TabIndex = 42;
            this.checkBox21.Text = "पॉइंट चार्ज";
            this.checkBox21.UseVisualStyleBackColor = true;
            this.checkBox21.CheckedChanged += new System.EventHandler(this.checkBox21_CheckedChanged);
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox16.Location = new System.Drawing.Point(117, 659);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(201, 28);
            this.checkBox16.TabIndex = 22;
            this.checkBox16.Text = "एस.टी.डी / पी.सी.ओ 200 वाट";
            this.checkBox16.UseVisualStyleBackColor = true;
            this.checkBox16.CheckedChanged += new System.EventHandler(this.checkBox16_CheckedChanged);
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox17.Location = new System.Drawing.Point(144, 625);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(176, 28);
            this.checkBox17.TabIndex = 21;
            this.checkBox17.Text = "फोटो स्टूडियो 4 किलोवाट";
            this.checkBox17.UseVisualStyleBackColor = true;
            this.checkBox17.CheckedChanged += new System.EventHandler(this.checkBox17_CheckedChanged);
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox18.Location = new System.Drawing.Point(144, 594);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(176, 28);
            this.checkBox18.TabIndex = 20;
            this.checkBox18.Text = "पॉपकॉर्न एवं कॉफ़ी मशीन";
            this.checkBox18.UseVisualStyleBackColor = true;
            this.checkBox18.CheckedChanged += new System.EventHandler(this.checkBox18_CheckedChanged);
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox19.Location = new System.Drawing.Point(187, 563);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(125, 28);
            this.checkBox19.TabIndex = 19;
            this.checkBox19.Text = "झूला 3 किलोवाट";
            this.checkBox19.UseVisualStyleBackColor = true;
            this.checkBox19.CheckedChanged += new System.EventHandler(this.checkBox19_CheckedChanged);
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox20.Location = new System.Drawing.Point(17, 529);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(295, 28);
            this.checkBox20.TabIndex = 18;
            this.checkBox20.Text = "सोफ्टी कनेक्शन 4 किलोवाट 3 फेस प्रति मशीन";
            this.checkBox20.UseVisualStyleBackColor = true;
            this.checkBox20.CheckedChanged += new System.EventHandler(this.checkBox20_CheckedChanged);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox11.Location = new System.Drawing.Point(173, 495);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(143, 28);
            this.checkBox11.TabIndex = 17;
            this.checkBox11.Text = "10 किलोवाट 3 फेस";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox12.Location = new System.Drawing.Point(181, 461);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(135, 28);
            this.checkBox12.TabIndex = 16;
            this.checkBox12.Text = "5 किलोवाट 3 फेस";
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox13.Location = new System.Drawing.Point(181, 433);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(135, 28);
            this.checkBox13.TabIndex = 15;
            this.checkBox13.Text = "3 किलोवाट 3 फेस";
            this.checkBox13.UseVisualStyleBackColor = true;
            this.checkBox13.CheckedChanged += new System.EventHandler(this.checkBox13_CheckedChanged);
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox14.Location = new System.Drawing.Point(141, 403);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(173, 28);
            this.checkBox14.TabIndex = 14;
            this.checkBox14.Text = "1.5 किलोवाट सिंगल फेस";
            this.checkBox14.UseVisualStyleBackColor = true;
            this.checkBox14.CheckedChanged += new System.EventHandler(this.checkBox14_CheckedChanged);
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox15.Location = new System.Drawing.Point(155, 369);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(162, 28);
            this.checkBox15.TabIndex = 13;
            this.checkBox15.Text = "1 किलोवाट सिंगल फेस";
            this.checkBox15.UseVisualStyleBackColor = true;
            this.checkBox15.CheckedChanged += new System.EventHandler(this.checkBox15_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6.Location = new System.Drawing.Point(155, 340);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(158, 28);
            this.checkBox6.TabIndex = 12;
            this.checkBox6.Text = "प्लग पॉइंट 1 किलोवाट";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox7.Location = new System.Drawing.Point(53, 309);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(256, 28);
            this.checkBox7.TabIndex = 11;
            this.checkBox7.Text = "रंगीन मिनिएचर बल्ब अधिकतम 100 नग";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox8.Location = new System.Drawing.Point(12, 277);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(307, 28);
            this.checkBox8.TabIndex = 10;
            this.checkBox8.Text = "प्लग पॉइंट 500 वाट (फोटोकापिेर / फैक्स मशीन)";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox9.Location = new System.Drawing.Point(64, 244);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(238, 28);
            this.checkBox9.TabIndex = 9;
            this.checkBox9.Text = "फिक्स्ड मिनिएचर अधिकतम 100 नग";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox10.Location = new System.Drawing.Point(164, 214);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(153, 28);
            this.checkBox10.TabIndex = 8;
            this.checkBox10.Text = "फटड लाइट 200 वाट";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox5.Location = new System.Drawing.Point(122, 180);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(187, 28);
            this.checkBox5.TabIndex = 7;
            this.checkBox5.Text = "सी.एफ.एल. 15, 18, 22 वाट";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.Location = new System.Drawing.Point(130, 146);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(179, 28);
            this.checkBox4.TabIndex = 6;
            this.checkBox4.Text = "सी.एफ.एल. 9, 11, 13 वाट";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(177, 116);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(138, 28);
            this.checkBox3.TabIndex = 5;
            this.checkBox3.Text = "ट्यूब लाइट 40 वाट";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(210, 88);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(108, 28);
            this.checkBox2.TabIndex = 4;
            this.checkBox2.Text = "बल्ब 200 वाट";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(164, 54);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(150, 28);
            this.checkBox1.TabIndex = 3;
            this.checkBox1.Text = "बल्ब 60 एवं 100 वाट";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(133, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 25);
            this.label8.TabIndex = 1;
            this.label8.Text = "नाम/वस्तु";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.textBox54);
            this.panel3.Controls.Add(this.textBox49);
            this.panel3.Controls.Add(this.textBox50);
            this.panel3.Controls.Add(this.textBox51);
            this.panel3.Controls.Add(this.textBox52);
            this.panel3.Controls.Add(this.textBox53);
            this.panel3.Controls.Add(this.textBox44);
            this.panel3.Controls.Add(this.textBox45);
            this.panel3.Controls.Add(this.textBox46);
            this.panel3.Controls.Add(this.textBox47);
            this.panel3.Controls.Add(this.textBox48);
            this.panel3.Controls.Add(this.textBox39);
            this.panel3.Controls.Add(this.textBox40);
            this.panel3.Controls.Add(this.textBox41);
            this.panel3.Controls.Add(this.textBox42);
            this.panel3.Controls.Add(this.textBox43);
            this.panel3.Controls.Add(this.textBox10);
            this.panel3.Controls.Add(this.textBox9);
            this.panel3.Controls.Add(this.textBox8);
            this.panel3.Controls.Add(this.textBox7);
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(364, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(89, 724);
            this.panel3.TabIndex = 18;
            // 
            // textBox54
            // 
            this.textBox54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox54.Location = new System.Drawing.Point(12, 691);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(59, 20);
            this.textBox54.TabIndex = 25;
            // 
            // textBox49
            // 
            this.textBox49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox49.Location = new System.Drawing.Point(11, 659);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(59, 20);
            this.textBox49.TabIndex = 22;
            // 
            // textBox50
            // 
            this.textBox50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox50.Location = new System.Drawing.Point(11, 626);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(59, 20);
            this.textBox50.TabIndex = 21;
            // 
            // textBox51
            // 
            this.textBox51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox51.Location = new System.Drawing.Point(11, 597);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(59, 20);
            this.textBox51.TabIndex = 20;
            // 
            // textBox52
            // 
            this.textBox52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox52.Location = new System.Drawing.Point(11, 566);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(59, 20);
            this.textBox52.TabIndex = 19;
            // 
            // textBox53
            // 
            this.textBox53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox53.Location = new System.Drawing.Point(11, 533);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(59, 20);
            this.textBox53.TabIndex = 18;
            // 
            // textBox44
            // 
            this.textBox44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox44.Location = new System.Drawing.Point(11, 501);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(59, 20);
            this.textBox44.TabIndex = 17;
            // 
            // textBox45
            // 
            this.textBox45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox45.Location = new System.Drawing.Point(11, 468);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(59, 20);
            this.textBox45.TabIndex = 16;
            // 
            // textBox46
            // 
            this.textBox46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox46.Location = new System.Drawing.Point(12, 439);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(59, 20);
            this.textBox46.TabIndex = 15;
            // 
            // textBox47
            // 
            this.textBox47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox47.Location = new System.Drawing.Point(11, 408);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(59, 20);
            this.textBox47.TabIndex = 14;
            // 
            // textBox48
            // 
            this.textBox48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox48.Location = new System.Drawing.Point(11, 375);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(59, 20);
            this.textBox48.TabIndex = 13;
            // 
            // textBox39
            // 
            this.textBox39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox39.Location = new System.Drawing.Point(11, 345);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(59, 20);
            this.textBox39.TabIndex = 12;
            // 
            // textBox40
            // 
            this.textBox40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox40.Location = new System.Drawing.Point(11, 315);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(59, 20);
            this.textBox40.TabIndex = 11;
            // 
            // textBox41
            // 
            this.textBox41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox41.Location = new System.Drawing.Point(11, 283);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(59, 20);
            this.textBox41.TabIndex = 10;
            // 
            // textBox42
            // 
            this.textBox42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox42.Location = new System.Drawing.Point(11, 252);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(59, 20);
            this.textBox42.TabIndex = 9;
            // 
            // textBox43
            // 
            this.textBox43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox43.Location = new System.Drawing.Point(11, 219);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(59, 20);
            this.textBox43.TabIndex = 8;
            // 
            // textBox10
            // 
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.Location = new System.Drawing.Point(13, 186);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(59, 20);
            this.textBox10.TabIndex = 7;
            // 
            // textBox9
            // 
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Location = new System.Drawing.Point(13, 154);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(59, 20);
            this.textBox9.TabIndex = 6;
            // 
            // textBox8
            // 
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.Location = new System.Drawing.Point(12, 121);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(59, 20);
            this.textBox8.TabIndex = 5;
            // 
            // textBox7
            // 
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.Location = new System.Drawing.Point(12, 90);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(59, 20);
            this.textBox7.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.Location = new System.Drawing.Point(12, 57);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(59, 20);
            this.textBox6.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(23, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 25);
            this.label9.TabIndex = 2;
            this.label9.Text = "संख्या";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.Controls.Add(this.textBox70);
            this.panel4.Controls.Add(this.textBox65);
            this.panel4.Controls.Add(this.textBox66);
            this.panel4.Controls.Add(this.textBox67);
            this.panel4.Controls.Add(this.textBox68);
            this.panel4.Controls.Add(this.textBox69);
            this.panel4.Controls.Add(this.textBox60);
            this.panel4.Controls.Add(this.textBox61);
            this.panel4.Controls.Add(this.textBox62);
            this.panel4.Controls.Add(this.textBox63);
            this.panel4.Controls.Add(this.textBox64);
            this.panel4.Controls.Add(this.textBox55);
            this.panel4.Controls.Add(this.textBox15);
            this.panel4.Controls.Add(this.textBox56);
            this.panel4.Controls.Add(this.textBox14);
            this.panel4.Controls.Add(this.textBox57);
            this.panel4.Controls.Add(this.textBox13);
            this.panel4.Controls.Add(this.textBox58);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.textBox59);
            this.panel4.Controls.Add(this.textBox12);
            this.panel4.Controls.Add(this.textBox11);
            this.panel4.Location = new System.Drawing.Point(450, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(121, 724);
            this.panel4.TabIndex = 19;
            // 
            // textBox70
            // 
            this.textBox70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox70.Location = new System.Drawing.Point(20, 694);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(79, 20);
            this.textBox70.TabIndex = 45;
            // 
            // textBox65
            // 
            this.textBox65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox65.Location = new System.Drawing.Point(20, 659);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(79, 20);
            this.textBox65.TabIndex = 44;
            // 
            // textBox66
            // 
            this.textBox66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox66.Location = new System.Drawing.Point(20, 626);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(79, 20);
            this.textBox66.TabIndex = 43;
            // 
            // textBox67
            // 
            this.textBox67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox67.Location = new System.Drawing.Point(20, 597);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(79, 20);
            this.textBox67.TabIndex = 42;
            // 
            // textBox68
            // 
            this.textBox68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox68.Location = new System.Drawing.Point(20, 566);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(79, 20);
            this.textBox68.TabIndex = 41;
            // 
            // textBox69
            // 
            this.textBox69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox69.Location = new System.Drawing.Point(20, 533);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(79, 20);
            this.textBox69.TabIndex = 40;
            // 
            // textBox60
            // 
            this.textBox60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox60.Location = new System.Drawing.Point(20, 501);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(79, 20);
            this.textBox60.TabIndex = 39;
            // 
            // textBox61
            // 
            this.textBox61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox61.Location = new System.Drawing.Point(20, 468);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(79, 20);
            this.textBox61.TabIndex = 38;
            // 
            // textBox62
            // 
            this.textBox62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox62.Location = new System.Drawing.Point(20, 438);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(79, 20);
            this.textBox62.TabIndex = 37;
            // 
            // textBox63
            // 
            this.textBox63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox63.Location = new System.Drawing.Point(20, 407);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(79, 20);
            this.textBox63.TabIndex = 36;
            // 
            // textBox64
            // 
            this.textBox64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox64.Location = new System.Drawing.Point(20, 375);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(79, 20);
            this.textBox64.TabIndex = 35;
            // 
            // textBox55
            // 
            this.textBox55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox55.Location = new System.Drawing.Point(20, 346);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(79, 20);
            this.textBox55.TabIndex = 34;
            // 
            // textBox15
            // 
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox15.Location = new System.Drawing.Point(20, 186);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(79, 20);
            this.textBox15.TabIndex = 24;
            // 
            // textBox56
            // 
            this.textBox56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox56.Location = new System.Drawing.Point(20, 315);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(79, 20);
            this.textBox56.TabIndex = 33;
            // 
            // textBox14
            // 
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox14.Location = new System.Drawing.Point(20, 152);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(79, 20);
            this.textBox14.TabIndex = 23;
            // 
            // textBox57
            // 
            this.textBox57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox57.Location = new System.Drawing.Point(20, 283);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(79, 20);
            this.textBox57.TabIndex = 32;
            // 
            // textBox13
            // 
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.Location = new System.Drawing.Point(20, 121);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(79, 20);
            this.textBox13.TabIndex = 22;
            // 
            // textBox58
            // 
            this.textBox58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox58.Location = new System.Drawing.Point(20, 250);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(79, 20);
            this.textBox58.TabIndex = 31;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 25);
            this.label11.TabIndex = 3;
            this.label11.Text = "फिटिंग चार्ज";
            // 
            // textBox59
            // 
            this.textBox59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox59.Location = new System.Drawing.Point(20, 219);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(79, 20);
            this.textBox59.TabIndex = 30;
            // 
            // textBox12
            // 
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.Location = new System.Drawing.Point(20, 90);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(79, 20);
            this.textBox12.TabIndex = 21;
            // 
            // textBox11
            // 
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.Location = new System.Drawing.Point(20, 57);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(79, 20);
            this.textBox11.TabIndex = 20;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.Controls.Add(this.textBox86);
            this.panel5.Controls.Add(this.textBox81);
            this.panel5.Controls.Add(this.textBox76);
            this.panel5.Controls.Add(this.textBox82);
            this.panel5.Controls.Add(this.textBox77);
            this.panel5.Controls.Add(this.textBox78);
            this.panel5.Controls.Add(this.textBox83);
            this.panel5.Controls.Add(this.textBox79);
            this.panel5.Controls.Add(this.textBox80);
            this.panel5.Controls.Add(this.textBox84);
            this.panel5.Controls.Add(this.textBox71);
            this.panel5.Controls.Add(this.textBox72);
            this.panel5.Controls.Add(this.textBox85);
            this.panel5.Controls.Add(this.textBox73);
            this.panel5.Controls.Add(this.textBox74);
            this.panel5.Controls.Add(this.textBox75);
            this.panel5.Controls.Add(this.textBox20);
            this.panel5.Controls.Add(this.textBox19);
            this.panel5.Controls.Add(this.textBox18);
            this.panel5.Controls.Add(this.textBox17);
            this.panel5.Controls.Add(this.textBox16);
            this.panel5.Controls.Add(this.button3);
            this.panel5.Controls.Add(this.button2);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Location = new System.Drawing.Point(551, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(132, 724);
            this.panel5.TabIndex = 20;
            // 
            // textBox86
            // 
            this.textBox86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox86.Location = new System.Drawing.Point(35, 692);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(79, 20);
            this.textBox86.TabIndex = 45;
            // 
            // textBox81
            // 
            this.textBox81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox81.Location = new System.Drawing.Point(35, 659);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(79, 20);
            this.textBox81.TabIndex = 44;
            // 
            // textBox76
            // 
            this.textBox76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox76.Location = new System.Drawing.Point(35, 501);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(79, 20);
            this.textBox76.TabIndex = 39;
            // 
            // textBox82
            // 
            this.textBox82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox82.Location = new System.Drawing.Point(35, 625);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(79, 20);
            this.textBox82.TabIndex = 43;
            // 
            // textBox77
            // 
            this.textBox77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox77.Location = new System.Drawing.Point(35, 468);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(79, 20);
            this.textBox77.TabIndex = 38;
            // 
            // textBox78
            // 
            this.textBox78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox78.Location = new System.Drawing.Point(35, 439);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(79, 20);
            this.textBox78.TabIndex = 37;
            // 
            // textBox83
            // 
            this.textBox83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox83.Location = new System.Drawing.Point(35, 597);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(79, 20);
            this.textBox83.TabIndex = 42;
            // 
            // textBox79
            // 
            this.textBox79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox79.Location = new System.Drawing.Point(35, 408);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(79, 20);
            this.textBox79.TabIndex = 36;
            // 
            // textBox80
            // 
            this.textBox80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox80.Location = new System.Drawing.Point(35, 375);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(79, 20);
            this.textBox80.TabIndex = 35;
            // 
            // textBox84
            // 
            this.textBox84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox84.Location = new System.Drawing.Point(35, 566);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(79, 20);
            this.textBox84.TabIndex = 41;
            // 
            // textBox71
            // 
            this.textBox71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox71.Location = new System.Drawing.Point(35, 345);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(79, 20);
            this.textBox71.TabIndex = 34;
            // 
            // textBox72
            // 
            this.textBox72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox72.Location = new System.Drawing.Point(35, 315);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(79, 20);
            this.textBox72.TabIndex = 33;
            // 
            // textBox85
            // 
            this.textBox85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox85.Location = new System.Drawing.Point(35, 535);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(79, 20);
            this.textBox85.TabIndex = 40;
            // 
            // textBox73
            // 
            this.textBox73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox73.Location = new System.Drawing.Point(35, 285);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(79, 20);
            this.textBox73.TabIndex = 32;
            // 
            // textBox74
            // 
            this.textBox74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox74.Location = new System.Drawing.Point(35, 252);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(79, 20);
            this.textBox74.TabIndex = 31;
            // 
            // textBox75
            // 
            this.textBox75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox75.Location = new System.Drawing.Point(35, 220);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(79, 20);
            this.textBox75.TabIndex = 30;
            // 
            // textBox20
            // 
            this.textBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox20.Location = new System.Drawing.Point(35, 186);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(79, 20);
            this.textBox20.TabIndex = 29;
            // 
            // textBox19
            // 
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox19.Location = new System.Drawing.Point(35, 153);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(79, 20);
            this.textBox19.TabIndex = 28;
            // 
            // textBox18
            // 
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox18.Location = new System.Drawing.Point(35, 122);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(79, 20);
            this.textBox18.TabIndex = 27;
            // 
            // textBox17
            // 
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox17.Location = new System.Drawing.Point(35, 87);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(79, 20);
            this.textBox17.TabIndex = 26;
            // 
            // textBox16
            // 
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.Location = new System.Drawing.Point(35, 54);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(79, 20);
            this.textBox16.TabIndex = 25;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(327, 165);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 21;
            this.button3.Text = "Refresh";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(-238, 165);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "Submit";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(30, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 25);
            this.label12.TabIndex = 4;
            this.label12.Text = "मेंटेनेंस चार्ज";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Control;
            this.panel6.Controls.Add(this.textBox102);
            this.panel6.Controls.Add(this.textBox97);
            this.panel6.Controls.Add(this.textBox98);
            this.panel6.Controls.Add(this.textBox99);
            this.panel6.Controls.Add(this.textBox100);
            this.panel6.Controls.Add(this.textBox101);
            this.panel6.Controls.Add(this.textBox92);
            this.panel6.Controls.Add(this.textBox93);
            this.panel6.Controls.Add(this.textBox94);
            this.panel6.Controls.Add(this.textBox95);
            this.panel6.Controls.Add(this.textBox96);
            this.panel6.Controls.Add(this.textBox87);
            this.panel6.Controls.Add(this.textBox88);
            this.panel6.Controls.Add(this.textBox89);
            this.panel6.Controls.Add(this.textBox90);
            this.panel6.Controls.Add(this.textBox91);
            this.panel6.Controls.Add(this.textBox25);
            this.panel6.Controls.Add(this.textBox24);
            this.panel6.Controls.Add(this.textBox23);
            this.panel6.Controls.Add(this.textBox22);
            this.panel6.Controls.Add(this.textBox21);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Location = new System.Drawing.Point(680, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(108, 724);
            this.panel6.TabIndex = 21;
            // 
            // textBox102
            // 
            this.textBox102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox102.Location = new System.Drawing.Point(14, 692);
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(79, 20);
            this.textBox102.TabIndex = 45;
            // 
            // textBox97
            // 
            this.textBox97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox97.Location = new System.Drawing.Point(14, 659);
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(79, 20);
            this.textBox97.TabIndex = 44;
            // 
            // textBox98
            // 
            this.textBox98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox98.Location = new System.Drawing.Point(14, 626);
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new System.Drawing.Size(79, 20);
            this.textBox98.TabIndex = 43;
            // 
            // textBox99
            // 
            this.textBox99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox99.Location = new System.Drawing.Point(14, 597);
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new System.Drawing.Size(79, 20);
            this.textBox99.TabIndex = 42;
            // 
            // textBox100
            // 
            this.textBox100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox100.Location = new System.Drawing.Point(14, 566);
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(79, 20);
            this.textBox100.TabIndex = 41;
            // 
            // textBox101
            // 
            this.textBox101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox101.Location = new System.Drawing.Point(14, 535);
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(79, 20);
            this.textBox101.TabIndex = 40;
            // 
            // textBox92
            // 
            this.textBox92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox92.Location = new System.Drawing.Point(14, 501);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(79, 20);
            this.textBox92.TabIndex = 39;
            // 
            // textBox93
            // 
            this.textBox93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox93.Location = new System.Drawing.Point(14, 467);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(79, 20);
            this.textBox93.TabIndex = 38;
            // 
            // textBox94
            // 
            this.textBox94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox94.Location = new System.Drawing.Point(14, 438);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(79, 20);
            this.textBox94.TabIndex = 37;
            // 
            // textBox95
            // 
            this.textBox95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox95.Location = new System.Drawing.Point(14, 408);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(79, 20);
            this.textBox95.TabIndex = 36;
            // 
            // textBox96
            // 
            this.textBox96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox96.Location = new System.Drawing.Point(14, 375);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(79, 20);
            this.textBox96.TabIndex = 35;
            // 
            // textBox87
            // 
            this.textBox87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox87.Location = new System.Drawing.Point(14, 345);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(79, 20);
            this.textBox87.TabIndex = 34;
            // 
            // textBox88
            // 
            this.textBox88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox88.Location = new System.Drawing.Point(14, 315);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(79, 20);
            this.textBox88.TabIndex = 33;
            // 
            // textBox89
            // 
            this.textBox89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox89.Location = new System.Drawing.Point(14, 285);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(79, 20);
            this.textBox89.TabIndex = 32;
            // 
            // textBox90
            // 
            this.textBox90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox90.Location = new System.Drawing.Point(14, 252);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(79, 20);
            this.textBox90.TabIndex = 31;
            // 
            // textBox91
            // 
            this.textBox91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox91.Location = new System.Drawing.Point(14, 219);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(79, 20);
            this.textBox91.TabIndex = 30;
            // 
            // textBox25
            // 
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox25.Location = new System.Drawing.Point(14, 186);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(79, 20);
            this.textBox25.TabIndex = 29;
            // 
            // textBox24
            // 
            this.textBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox24.Location = new System.Drawing.Point(14, 154);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(79, 20);
            this.textBox24.TabIndex = 28;
            // 
            // textBox23
            // 
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox23.Location = new System.Drawing.Point(14, 124);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(79, 20);
            this.textBox23.TabIndex = 27;
            // 
            // textBox22
            // 
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox22.Location = new System.Drawing.Point(14, 89);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(79, 20);
            this.textBox22.TabIndex = 26;
            // 
            // textBox21
            // 
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox21.Location = new System.Drawing.Point(14, 54);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(79, 20);
            this.textBox21.TabIndex = 25;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(22, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 25);
            this.label13.TabIndex = 5;
            this.label13.Text = "डिपॉजिट";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.Controls.Add(this.textBox118);
            this.panel7.Controls.Add(this.textBox113);
            this.panel7.Controls.Add(this.textBox114);
            this.panel7.Controls.Add(this.textBox115);
            this.panel7.Controls.Add(this.textBox116);
            this.panel7.Controls.Add(this.textBox117);
            this.panel7.Controls.Add(this.textBox108);
            this.panel7.Controls.Add(this.textBox109);
            this.panel7.Controls.Add(this.textBox110);
            this.panel7.Controls.Add(this.textBox111);
            this.panel7.Controls.Add(this.textBox112);
            this.panel7.Controls.Add(this.textBox103);
            this.panel7.Controls.Add(this.textBox104);
            this.panel7.Controls.Add(this.textBox105);
            this.panel7.Controls.Add(this.textBox106);
            this.panel7.Controls.Add(this.textBox107);
            this.panel7.Controls.Add(this.textBox30);
            this.panel7.Controls.Add(this.textBox29);
            this.panel7.Controls.Add(this.textBox28);
            this.panel7.Controls.Add(this.textBox27);
            this.panel7.Controls.Add(this.textBox26);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Location = new System.Drawing.Point(750, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(179, 724);
            this.panel7.TabIndex = 22;
            // 
            // textBox118
            // 
            this.textBox118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox118.Location = new System.Drawing.Point(55, 693);
            this.textBox118.Name = "textBox118";
            this.textBox118.Size = new System.Drawing.Size(107, 20);
            this.textBox118.TabIndex = 45;
            // 
            // textBox113
            // 
            this.textBox113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox113.Location = new System.Drawing.Point(55, 659);
            this.textBox113.Name = "textBox113";
            this.textBox113.Size = new System.Drawing.Size(107, 20);
            this.textBox113.TabIndex = 44;
            // 
            // textBox114
            // 
            this.textBox114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox114.Location = new System.Drawing.Point(55, 626);
            this.textBox114.Name = "textBox114";
            this.textBox114.Size = new System.Drawing.Size(107, 20);
            this.textBox114.TabIndex = 43;
            // 
            // textBox115
            // 
            this.textBox115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox115.Location = new System.Drawing.Point(55, 597);
            this.textBox115.Name = "textBox115";
            this.textBox115.Size = new System.Drawing.Size(107, 20);
            this.textBox115.TabIndex = 42;
            // 
            // textBox116
            // 
            this.textBox116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox116.Location = new System.Drawing.Point(55, 565);
            this.textBox116.Name = "textBox116";
            this.textBox116.Size = new System.Drawing.Size(107, 20);
            this.textBox116.TabIndex = 41;
            // 
            // textBox117
            // 
            this.textBox117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox117.Location = new System.Drawing.Point(55, 535);
            this.textBox117.Name = "textBox117";
            this.textBox117.Size = new System.Drawing.Size(107, 20);
            this.textBox117.TabIndex = 40;
            // 
            // textBox108
            // 
            this.textBox108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox108.Location = new System.Drawing.Point(55, 501);
            this.textBox108.Name = "textBox108";
            this.textBox108.Size = new System.Drawing.Size(107, 20);
            this.textBox108.TabIndex = 39;
            // 
            // textBox109
            // 
            this.textBox109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox109.Location = new System.Drawing.Point(55, 468);
            this.textBox109.Name = "textBox109";
            this.textBox109.Size = new System.Drawing.Size(107, 20);
            this.textBox109.TabIndex = 38;
            // 
            // textBox110
            // 
            this.textBox110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox110.Location = new System.Drawing.Point(55, 438);
            this.textBox110.Name = "textBox110";
            this.textBox110.Size = new System.Drawing.Size(107, 20);
            this.textBox110.TabIndex = 37;
            // 
            // textBox111
            // 
            this.textBox111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox111.Location = new System.Drawing.Point(55, 408);
            this.textBox111.Name = "textBox111";
            this.textBox111.Size = new System.Drawing.Size(107, 20);
            this.textBox111.TabIndex = 36;
            // 
            // textBox112
            // 
            this.textBox112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox112.Location = new System.Drawing.Point(55, 375);
            this.textBox112.Name = "textBox112";
            this.textBox112.Size = new System.Drawing.Size(107, 20);
            this.textBox112.TabIndex = 35;
            // 
            // textBox103
            // 
            this.textBox103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox103.Location = new System.Drawing.Point(55, 346);
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(107, 20);
            this.textBox103.TabIndex = 34;
            // 
            // textBox104
            // 
            this.textBox104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox104.Location = new System.Drawing.Point(55, 315);
            this.textBox104.Name = "textBox104";
            this.textBox104.Size = new System.Drawing.Size(107, 20);
            this.textBox104.TabIndex = 33;
            // 
            // textBox105
            // 
            this.textBox105.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox105.Location = new System.Drawing.Point(55, 285);
            this.textBox105.Name = "textBox105";
            this.textBox105.Size = new System.Drawing.Size(107, 20);
            this.textBox105.TabIndex = 32;
            // 
            // textBox106
            // 
            this.textBox106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox106.Location = new System.Drawing.Point(55, 252);
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new System.Drawing.Size(107, 20);
            this.textBox106.TabIndex = 31;
            // 
            // textBox107
            // 
            this.textBox107.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox107.Location = new System.Drawing.Point(55, 219);
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(107, 20);
            this.textBox107.TabIndex = 30;
            // 
            // textBox30
            // 
            this.textBox30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox30.Location = new System.Drawing.Point(55, 186);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(107, 20);
            this.textBox30.TabIndex = 29;
            // 
            // textBox29
            // 
            this.textBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox29.Location = new System.Drawing.Point(55, 154);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(107, 20);
            this.textBox29.TabIndex = 28;
            // 
            // textBox28
            // 
            this.textBox28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox28.Location = new System.Drawing.Point(55, 122);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(107, 20);
            this.textBox28.TabIndex = 27;
            // 
            // textBox27
            // 
            this.textBox27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox27.Location = new System.Drawing.Point(55, 87);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(107, 20);
            this.textBox27.TabIndex = 26;
            // 
            // textBox26
            // 
            this.textBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox26.Location = new System.Drawing.Point(55, 54);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(107, 20);
            this.textBox26.TabIndex = 25;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(68, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 25);
            this.label14.TabIndex = 6;
            this.label14.Text = "कुल रकम";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Control;
            this.panel8.Controls.Add(this.label39);
            this.panel8.Controls.Add(this.label29);
            this.panel8.Controls.Add(this.label30);
            this.panel8.Controls.Add(this.label31);
            this.panel8.Controls.Add(this.label32);
            this.panel8.Controls.Add(this.label33);
            this.panel8.Controls.Add(this.label34);
            this.panel8.Controls.Add(this.label35);
            this.panel8.Controls.Add(this.label36);
            this.panel8.Controls.Add(this.label37);
            this.panel8.Controls.Add(this.label38);
            this.panel8.Controls.Add(this.label24);
            this.panel8.Controls.Add(this.label25);
            this.panel8.Controls.Add(this.label26);
            this.panel8.Controls.Add(this.label27);
            this.panel8.Controls.Add(this.label28);
            this.panel8.Controls.Add(this.label19);
            this.panel8.Controls.Add(this.label18);
            this.panel8.Controls.Add(this.label17);
            this.panel8.Controls.Add(this.label16);
            this.panel8.Controls.Add(this.label15);
            this.panel8.Controls.Add(this.label7);
            this.panel8.Location = new System.Drawing.Point(-8, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(50, 731);
            this.panel8.TabIndex = 16;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(11, 703);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(33, 17);
            this.label39.TabIndex = 36;
            this.label39.Text = "21).";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(14, 666);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(33, 17);
            this.label29.TabIndex = 35;
            this.label29.Text = "20).";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(13, 626);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(33, 17);
            this.label30.TabIndex = 34;
            this.label30.Text = "19).";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(14, 594);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(33, 17);
            this.label31.TabIndex = 33;
            this.label31.Text = "18).";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(13, 566);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(33, 17);
            this.label32.TabIndex = 32;
            this.label32.Text = "17).";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(13, 531);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(33, 17);
            this.label33.TabIndex = 31;
            this.label33.Text = "16).";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(13, 495);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(33, 17);
            this.label34.TabIndex = 30;
            this.label34.Text = "15).";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(13, 465);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(33, 17);
            this.label35.TabIndex = 29;
            this.label35.Text = "14).";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(13, 433);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(33, 17);
            this.label36.TabIndex = 28;
            this.label36.Text = "13).";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(13, 402);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(33, 17);
            this.label37.TabIndex = 27;
            this.label37.Text = "12).";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(13, 369);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(33, 17);
            this.label38.TabIndex = 26;
            this.label38.Text = "11).";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(13, 339);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(33, 17);
            this.label24.TabIndex = 25;
            this.label24.Text = "10).";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(13, 309);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(25, 17);
            this.label25.TabIndex = 24;
            this.label25.Text = "9).";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(13, 277);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(25, 17);
            this.label26.TabIndex = 23;
            this.label26.Text = "8).";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(13, 246);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(25, 17);
            this.label27.TabIndex = 22;
            this.label27.Text = "7).";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(13, 213);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(25, 17);
            this.label28.TabIndex = 21;
            this.label28.Text = "6).";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(13, 183);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(25, 17);
            this.label19.TabIndex = 20;
            this.label19.Text = "5).";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(13, 153);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(25, 17);
            this.label18.TabIndex = 5;
            this.label18.Text = "4).";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(13, 121);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(25, 17);
            this.label17.TabIndex = 4;
            this.label17.Text = "3).";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(13, 90);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(25, 17);
            this.label16.TabIndex = 3;
            this.label16.Text = "2).";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(13, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 17);
            this.label15.TabIndex = 2;
            this.label15.Text = "1).";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(16, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 25);
            this.label7.TabIndex = 0;
            this.label7.Text = "न.";
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(973, 570);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(146, 46);
            this.button4.TabIndex = 31;
            this.button4.Text = "पुराना सेव करें";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(973, 516);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 46);
            this.button5.TabIndex = 30;
            this.button5.Text = "सेव करें";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(3, 3);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(99, 41);
            this.button6.TabIndex = 32;
            this.button6.Text = "कैलकुलेट करें";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox38
            // 
            this.textBox38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox38.Location = new System.Drawing.Point(281, 286);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(56, 20);
            this.textBox38.TabIndex = 33;
            this.textBox38.TextChanged += new System.EventHandler(this.textBox38_TextChanged);
            // 
            // textBox37
            // 
            this.textBox37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox37.Location = new System.Drawing.Point(550, 676);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(162, 20);
            this.textBox37.TabIndex = 39;
            this.textBox37.TextChanged += new System.EventHandler(this.textBox37_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(442, 669);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(102, 29);
            this.label22.TabIndex = 38;
            this.label22.Text = "बकाया राशि";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // textBox36
            // 
            this.textBox36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox36.Location = new System.Drawing.Point(261, 679);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(124, 20);
            this.textBox36.TabIndex = 36;
            this.textBox36.TextChanged += new System.EventHandler(this.textBox36_TextChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(169, 671);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 29);
            this.label21.TabIndex = 37;
            this.label21.Text = "जमा राशि";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel13.Controls.Add(this.textBox35);
            this.panel13.Controls.Add(this.textBox34);
            this.panel13.Controls.Add(this.textBox33);
            this.panel13.Controls.Add(this.textBox32);
            this.panel13.Controls.Add(this.textBox31);
            this.panel13.Controls.Add(this.label20);
            this.panel13.Controls.Add(this.button6);
            this.panel13.Location = new System.Drawing.Point(7, 618);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(808, 47);
            this.panel13.TabIndex = 35;
            this.panel13.Paint += new System.Windows.Forms.PaintEventHandler(this.panel13_Paint);
            // 
            // textBox35
            // 
            this.textBox35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox35.Location = new System.Drawing.Point(684, 16);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(107, 20);
            this.textBox35.TabIndex = 29;
            // 
            // textBox34
            // 
            this.textBox34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox34.Location = new System.Drawing.Point(569, 16);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(79, 20);
            this.textBox34.TabIndex = 28;
            // 
            // textBox33
            // 
            this.textBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox33.Location = new System.Drawing.Point(461, 16);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(79, 20);
            this.textBox33.TabIndex = 27;
            // 
            // textBox32
            // 
            this.textBox32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox32.Location = new System.Drawing.Point(345, 16);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(79, 20);
            this.textBox32.TabIndex = 26;
            // 
            // textBox31
            // 
            this.textBox31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox31.Location = new System.Drawing.Point(251, 16);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(60, 20);
            this.textBox31.TabIndex = 25;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(181, 8);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 31);
            this.label20.TabIndex = 18;
            this.label20.Text = "योग";
            // 
            // textBox119
            // 
            this.textBox119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox119.Location = new System.Drawing.Point(189, 127);
            this.textBox119.Name = "textBox119";
            this.textBox119.Size = new System.Drawing.Size(61, 20);
            this.textBox119.TabIndex = 41;
            this.textBox119.TextChanged += new System.EventHandler(this.textBox119_TextChanged);
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(973, 464);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(191, 46);
            this.button7.TabIndex = 42;
            this.button7.Text = "बची हुई रकम कैलकुलेट करें";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox120
            // 
            this.textBox120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox120.Location = new System.Drawing.Point(340, 130);
            this.textBox120.Name = "textBox120";
            this.textBox120.Size = new System.Drawing.Size(85, 20);
            this.textBox120.TabIndex = 44;
            this.textBox120.TextChanged += new System.EventHandler(this.textBox120_TextChanged);
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // button8
            // 
            this.button8.Enabled = false;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(973, 622);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(105, 44);
            this.button8.TabIndex = 45;
            this.button8.Text = "प्रिंट";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(256, 124);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(37, 25);
            this.label42.TabIndex = 50;
            this.label42.Text = "तक";
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(160, 124);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(24, 25);
            this.label43.TabIndex = 49;
            this.label43.Text = "से";
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(307, 127);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(32, 25);
            this.label44.TabIndex = 48;
            this.label44.Text = "वर्ष";
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(19, 121);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(71, 25);
            this.label45.TabIndex = 47;
            this.label45.Text = "दूकान न.";
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(567, 127);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(52, 25);
            this.label46.TabIndex = 46;
            this.label46.Text = "तारीख";
            this.label46.Click += new System.EventHandler(this.label46_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(343, 280);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 25);
            this.label10.TabIndex = 52;
            this.label10.Text = "तक";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(256, 282);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(24, 25);
            this.label23.TabIndex = 51;
            this.label23.Text = "से";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(191, 150);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(24, 25);
            this.label41.TabIndex = 56;
            this.label41.Text = "से";
            this.label41.Click += new System.EventHandler(this.label41_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(12, 150);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(79, 25);
            this.label47.TabIndex = 55;
            this.label47.Text = "कोठरी  न.";
            this.label47.Click += new System.EventHandler(this.label47_Click);
            // 
            // textBox121
            // 
            this.textBox121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox121.Location = new System.Drawing.Point(220, 153);
            this.textBox121.Name = "textBox121";
            this.textBox121.Size = new System.Drawing.Size(61, 20);
            this.textBox121.TabIndex = 54;
            this.textBox121.TextChanged += new System.EventHandler(this.textBox121_TextChanged);
            // 
            // textBox122
            // 
            this.textBox122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox122.Location = new System.Drawing.Point(127, 153);
            this.textBox122.Name = "textBox122";
            this.textBox122.Size = new System.Drawing.Size(57, 20);
            this.textBox122.TabIndex = 53;
            this.textBox122.TextChanged += new System.EventHandler(this.textBox122_TextChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(565, 282);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(24, 25);
            this.label40.TabIndex = 60;
            this.label40.Text = "से";
            this.label40.Click += new System.EventHandler(this.label40_Click);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(405, 282);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(79, 25);
            this.label48.TabIndex = 59;
            this.label48.Text = "कोठरी  न.";
            this.label48.Click += new System.EventHandler(this.label48_Click);
            // 
            // textBox123
            // 
            this.textBox123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox123.Location = new System.Drawing.Point(594, 285);
            this.textBox123.Name = "textBox123";
            this.textBox123.Size = new System.Drawing.Size(61, 20);
            this.textBox123.TabIndex = 58;
            this.textBox123.TextChanged += new System.EventHandler(this.textBox123_TextChanged);
            // 
            // textBox124
            // 
            this.textBox124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox124.Location = new System.Drawing.Point(501, 285);
            this.textBox124.Name = "textBox124";
            this.textBox124.Size = new System.Drawing.Size(57, 20);
            this.textBox124.TabIndex = 57;
            this.textBox124.TextChanged += new System.EventHandler(this.textBox124_TextChanged);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(159, -2);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(612, 64);
            this.label49.TabIndex = 73;
            this.label49.Text = "ग्वालियर व्यापार मेला प्राधिकरण ";
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(1176, 709);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.textBox123);
            this.Controls.Add(this.textBox124);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.textBox121);
            this.Controls.Add(this.textBox122);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.textBox120);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.textBox119);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label1);
            this.Name = "Form7";
            this.Text = "बिजली किराया";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form7_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.TextBox textBox113;
        private System.Windows.Forms.TextBox textBox114;
        private System.Windows.Forms.TextBox textBox115;
        private System.Windows.Forms.TextBox textBox116;
        private System.Windows.Forms.TextBox textBox117;
        private System.Windows.Forms.TextBox textBox108;
        private System.Windows.Forms.TextBox textBox109;
        private System.Windows.Forms.TextBox textBox110;
        private System.Windows.Forms.TextBox textBox111;
        private System.Windows.Forms.TextBox textBox112;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.TextBox textBox119;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox120;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.TextBox textBox122;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox123;
        private System.Windows.Forms.TextBox textBox124;
        private System.Windows.Forms.Label label49;
    }
}