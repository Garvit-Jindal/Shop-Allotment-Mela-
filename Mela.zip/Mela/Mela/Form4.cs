﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        { int a = 1;
            int no = int.Parse(textBox11.Text);
            int no1 = int.Parse(textBox12.Text);
            int no3 = int.Parse(textBox15.Text);
            int no4 = int.Parse(textBox14.Text);
            string year1 = textBox13.Text;
             
            if (no > 0)
            {

                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string Name = string.Format("  Select name,fname,address,year,paidreservation,paidcharge15,paidtotal,shopnofrom,shopnoto,storenofrom,storenoto from Reservation where shopnofrom={0} and shopnoto={1} and year=' {2}' and storenofrom={3} and storenoto={4} ", no, no1, year1, no3, no4);
                SqlCommand cmd = new SqlCommand(Name, cn);

                SqlDataReader rec = cmd.ExecuteReader();


                   


                    if (rec.Read())
                    {

                        string name = string.Format(" {0} ", rec.GetValue(0));
                        textBox1.Text = name + "";
                        string fname = string.Format(" {0} ", rec.GetValue(1));
                        textBox2.Text = fname + "";
                        string add = string.Format(" {0} ", rec.GetValue(2));
                        textBox3.Text = add + "";
                        string year = string.Format(" {0} ", rec.GetValue(3));
                        textBox4.Text = year + "";

                    
                        string from = string.Format(" {0} ", rec.GetValue(7));
                        textBox5.Text = from + "";
                        string to = string.Format(" {0} ", rec.GetValue(8));
                        textBox7.Text = to + "";
                        int store = int.Parse(string.Format(" {0} ", rec.GetValue(9)));
                        textBox17.Text = store.ToString();
                        int store1 = int.Parse(string.Format(" {0} ", rec.GetValue(10)));
                        textBox16.Text = store1.ToString();
                    button4.Enabled = true;
                    }

                }
            else
            {
                MessageBox.Show("no record found at shop = " + no);
            }
        }
           
        

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                textBox10.Text = "Nagad";

            }
            else
            {
                textBox10.Text = "";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                label14.Text = "DD kramank :";


            }
            else
            {
                label14.Text = "Nagad :";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string date = dateTimePicker1.Text;
                string name = textBox1.Text;
                string fname = textBox2.Text;
                string add = textBox3.Text;
                string year = textBox4.Text;
                int from = int.Parse(textBox5.Text);
                int too = int.Parse(textBox7.Text);
                int store = int.Parse(textBox17.Text);
                int store1 = int.Parse(textBox16.Text);
                int a = int.Parse(textBox6.Text);
                int b = int.Parse(textBox8.Text);
                int c = int.Parse(textBox9.Text);
                string d = textBox10.Text;
                string date1 = dateTimePicker2.Text;

                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string query = string.Format("insert into Payment values('{0}','{1}','{2}','{3}','{4}',{5},{6},{7},{8},{9},'{10}','{11}',{12},{13})",date,name,fname,add,year,from,too,a,b,c,d,date1,store,store1);
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record submitted ....");
                cn.Close();
                button4.Enabled = true;

            }
            catch (Exception ef)
            {

                MessageBox.Show(ef.Message);
            }


        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;
        private void PrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PrintScreen();
            printPreviewDialog1.ShowDialog();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            int a = 0;
            textBox14.Text = a.ToString();
            textBox15.Text = a.ToString();
        }
    }
}
