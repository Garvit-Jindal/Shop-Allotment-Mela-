﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class Bijlikirayarate : Form
    {
        public Bijlikirayarate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

                string name1 = label23.Text;
                int f1 = int.Parse(textBox1.Text);
                int m1 = int.Parse(textBox42.Text);
                int j1 = int.Parse(textBox63.Text);

                string query = string.Format("insert into Electricity1 values(N'बल्ब 60 एवं 100 वाट',{1},{2},{3})", name1,f1,m1,j1);
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name2 = label24.Text;
                int f2 = int.Parse(textBox2.Text);
                int m2 = int.Parse(textBox41.Text);
                int j2 = int.Parse(textBox62.Text);

                 query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name2, f2, m2, j2);
                 cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name3 = label25.Text;
                int f3 = int.Parse(textBox3.Text);
                int m3 = int.Parse(textBox40.Text);
                int j3 = int.Parse(textBox61.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name3, f3, m3, j3);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name4 = label26.Text;
                int f4 = int.Parse(textBox4.Text);
                int m4 = int.Parse(textBox39.Text);
                int j4 = int.Parse(textBox60.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name4, f4, m4, j4);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name5 = label27.Text;
                int f5 = int.Parse(textBox5.Text);
                int m5 = int.Parse(textBox38.Text);
                int j5 = int.Parse(textBox59.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name5, f5, m5, j5);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name6 = label28.Text;
                int f6 = int.Parse(textBox6.Text);
                int m6 = int.Parse(textBox37.Text);
                int j6 = int.Parse(textBox58.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name6, f6, m6, j6);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name7 = label29.Text;
                int f7 = int.Parse(textBox7.Text);
                int m7 = int.Parse(textBox36.Text);
                int j7 = int.Parse(textBox57.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name7, f7, m7, j7);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name8 = label30.Text;
                int f8 = int.Parse(textBox8.Text);
                int m8 = int.Parse(textBox35.Text);
                int j8 = int.Parse(textBox56.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name8, f8, m8, j8);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name9 = label31.Text;
                int f9 = int.Parse(textBox9.Text);
                int m9 = int.Parse(textBox34.Text);
                int j9 = int.Parse(textBox55.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name9, f9, m9, j9);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name10 = label32.Text;
                int f10 = int.Parse(textBox10.Text);
                int m10 = int.Parse(textBox33.Text);
                int j10 = int.Parse(textBox54.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name10, f10, m10, j10);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name11 = label33.Text;
                int f11 = int.Parse(textBox11.Text);
                int m11 = int.Parse(textBox32.Text);
                int j11 = int.Parse(textBox53.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name11, f11, m11, j11);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name12 = label34.Text;
                int f12 = int.Parse(textBox12.Text);
                int m12 = int.Parse(textBox31.Text);
                int j12 = int.Parse(textBox52.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name12, f12, m12, j12);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();


                string name13 = label35.Text;
                int f13 = int.Parse(textBox13.Text);
                int m13 = int.Parse(textBox30.Text);
                int j13 = int.Parse(textBox51.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name13, f13, m13, j13);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name14 = label36.Text;
                int f14 = int.Parse(textBox14.Text);
                int m14 = int.Parse(textBox29.Text);
                int j14 = int.Parse(textBox50.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name14, f14, m14, j14);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();


                string name15 = label37.Text;
                int f15 = int.Parse(textBox15.Text);
                int m15 = int.Parse(textBox28.Text);
                int j15 = int.Parse(textBox49.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name15, f15, m15, j15);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();


                string name16 = label38.Text;
                int f16 = int.Parse(textBox16.Text);
                int m16 = int.Parse(textBox27.Text);
                int j16 = int.Parse(textBox48.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name16, f16, m16, j16);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name17 = label39.Text;
                int f17 = int.Parse(textBox17.Text);
                int m17 = int.Parse(textBox26.Text);
                int j17 = int.Parse(textBox47.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name17, f17, m17, j17);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name18 = label40.Text;
                int f18 = int.Parse(textBox18.Text);
                int m18 = int.Parse(textBox25.Text);
                int j18 = int.Parse(textBox46.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name18, f18, m18, j18);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name19 = label41.Text;
                int f19 = int.Parse(textBox19.Text);
                int m19 = int.Parse(textBox24.Text);
                int j19 = int.Parse(textBox45.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name19, f19, m19, j19);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name20 = label42.Text;
                int f20 = int.Parse(textBox20.Text);
                int m20 = int.Parse(textBox23.Text);
                int j20 = int.Parse(textBox44.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name20, f20, m20, j20);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                string name21 = label43.Text;
                int f21 = int.Parse(textBox21.Text);
                int m21 = int.Parse(textBox22.Text);
                int j21 = int.Parse(textBox43.Text);

                query = string.Format("insert into Electricity1 values(N'{0}',{1},{2},{3})", name21, f21, m21, j21);
                cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Record  Submitted");
            }
            catch (Exception g)
            {

                MessageBox.Show(g.Message);

            }
        }
    }
}
