﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class Form3 : Form
    {
        
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int a = 1;
                
                
                int no = Int32.Parse(textBox5.Text);
                string year1 = textBox15.Text.TrimStart();
                int no1 = int.Parse(textBox24.Text);
                int no3 = int.Parse(textBox39.Text);
                int no4 = int.Parse(textBox35.Text);
                if (no > 0&& no1>0&&no3>=0&&no4>=0)

                {
                    
                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();
                    string Name = string.Format("  Select * from Reservation where shopnofrom={0} and shopnoto={2} and year=' {1}' and storenofrom={3} and storenoto={4}", no, year1, no1,no3,no4);
                    
                    SqlCommand cmd = new SqlCommand(Name, cn);

                    SqlDataReader rec = cmd.ExecuteReader();

                    if (rec.Read())
                    {

                        string date = string.Format(" {0} ", rec.GetValue(0));
                        dateTimePicker1.Text = date + "";

                        string name = string.Format(" {0} ", rec.GetValue(1));
                        textBox1.Text = name + "";

                        string fname = string.Format(" {0} ", rec.GetValue(2));
                        textBox2.Text = fname + "";

                        string add = string.Format(" {0} ", rec.GetValue(3));
                        textBox3.Text = add + "";

                        string year = string.Format(" {0} ", rec.GetValue(4));
                        textBox4.Text = year + "";
                        textBox6.Text = year + "";

                        string block = string.Format(" {0} ", rec.GetValue(5));
                        textBox7.Text = block + "";

                        string from = string.Format(" {0} ", rec.GetValue(6));
                        textBox8.Text = from + "";

                        string to = string.Format(" {0} ", rec.GetValue(7));
                        textBox9.Text = to + "";

                        string sno = string.Format(" {0} ", rec.GetValue(8));
                        textBox10.Text = sno + "";

                        string cat = string.Format(" {0} ", rec.GetValue(9));
                        textBox11.Text = cat + "";

                        string res = string.Format(" {0} ", rec.GetValue(10));
                        textBox12.Text = res + "";

                        string c = string.Format(" {0} ", rec.GetValue(11));
                        textBox13.Text = c + "";

                        string d = string.Format(" {0} ", rec.GetValue(12));
                        textBox14.Text = d + "";

                        string f = string.Format(" {0} ", rec.GetValue(13));
                        textBox16.Text = f + "";

                        string g = string.Format(" {0} ", rec.GetValue(14));
                        textBox17.Text = g + "";

                        string h = string.Format(" {0} ", rec.GetValue(15));
                        textBox18.Text = h + "";

                        string i = string.Format(" {0} ", rec.GetValue(16));
                        textBox19.Text = i + "";

                        string j = string.Format(" {0} ", rec.GetValue(17));
                        textBox20.Text = j + "";

                        string t = string.Format(" {0} ", rec.GetValue(18));
                        textBox40.Text = t + "";

                        string res1 = string.Format(" {0} ", rec.GetValue(19));
                        textBox21.Text = res1 + "";

                        string c1 = string.Format(" {0} ", rec.GetValue(20));
                        textBox22.Text = c1 + "";

                        string d1 = string.Format(" {0} ", rec.GetValue(21));
                        textBox23.Text = d1 + "";

                        string f1 = string.Format(" {0} ", rec.GetValue(22));
                        textBox25.Text = f1 + "";

                        string g1 = string.Format(" {0} ", rec.GetValue(23));
                        textBox26.Text = g1 + "";

                        string h1 = string.Format(" {0} ", rec.GetValue(24));
                        textBox27.Text = h1 + "";

                        string i1 = string.Format(" {0} ", rec.GetValue(25));
                        textBox28.Text = i1 + "";

                        string j1 = string.Format(" {0} ", rec.GetValue(26));
                        textBox29.Text = j1 + "";

                        string t1 = string.Format(" {0} ", rec.GetValue(27));
                        textBox41.Text = t1 + "";

                        string res2 = string.Format(" {0} ", rec.GetValue(28));
                        textBox38.Text = res2 + "";

                        string c2 = string.Format(" {0} ", rec.GetValue(29));
                        textBox37.Text = c2 + "";

                        string d2 = string.Format(" {0} ", rec.GetValue(30));
                        textBox36.Text = d2 + "";

                        string f2 = string.Format(" {0} ", rec.GetValue(31));
                        textBox34.Text = f2 + "";

                        string g2 = string.Format(" {0} ", rec.GetValue(32));
                        textBox33.Text = g2 + "";

                        string h2 = string.Format(" {0} ", rec.GetValue(33));
                        textBox32.Text = h2 + "";

                        string i2 = string.Format(" {0} ", rec.GetValue(34));
                        textBox31.Text = i2 + "";

                        string j2 = string.Format(" {0} ", rec.GetValue(35));
                        textBox30.Text = j2 + "";

                        string t2 = string.Format(" {0} ", rec.GetValue(36));
                        textBox42.Text = t2 + "";

                        int store = int.Parse(string.Format(" {0} ", rec.GetValue(37)));
                        textBox44.Text = store.ToString();

                        int store1 = int.Parse(string.Format(" {0} ", rec.GetValue(38)));
                        textBox43.Text = store1.ToString();


                        button5.Enabled = true;
                        a = 0;
                    }
                    else if (a == 1)
                    {
                        rec.Close();

                        Name = string.Format("Select name,fname,address,year,blockno,Registration.shopnofrom ,shopnoto,noofshops,category,reservationfee,rent,charge50,charge25,charge15,lastyear,coveredcharge,other,storenofrom,storenoto from Registration,Shopfee where registration.shopnofrom={0} and registration.shopnoto={2} and Shopfee.shopnofrom={0} and year='{1}' and storenofrom={3} and storenoto={4}", no, year1, no1,no3,no4);

                        cmd = new SqlCommand(Name, cn);

                        rec = cmd.ExecuteReader();


                        if (rec.Read())
                        {

                            string name = string.Format(" {0} ", rec.GetValue(0));
                            textBox1.Text = name + "";
                            string fname = string.Format(" {0} ", rec.GetValue(1));
                            textBox2.Text = fname + "";
                            string add = string.Format(" {0} ", rec.GetValue(2));
                            textBox3.Text = add + "";
                            string year = string.Format(" {0} ", rec.GetValue(3));
                            textBox4.Text = year + "";
                            textBox6.Text = year + "";
                            string block = string.Format(" {0} ", rec.GetValue(4));
                            textBox7.Text = block + "";
                            string from = string.Format(" {0} ", rec.GetValue(5));
                            textBox8.Text = from + "";
                            string to = string.Format(" {0} ", rec.GetValue(6));
                            textBox9.Text = to + "";
                            string sno = string.Format(" {0} ", rec.GetValue(7));
                            textBox10.Text = sno + "";
                            string cat = string.Format(" {0} ", rec.GetValue(8));
                            textBox11.Text = cat + "";

                            int store = int.Parse(string.Format(" {0} ", rec.GetValue(17)));
                            textBox44.Text = store.ToString();
                            int store1 = int.Parse(string.Format(" {0} ", rec.GetValue(18)));
                            textBox43.Text = store1.ToString();

                            int frm = int.Parse(from);
                            int too = int.Parse(to);

                            int v = 0;
                            textBox40.Text = v.ToString() + "";
                            textBox41.Text = v.ToString() + "";
                            textBox42.Text = v.ToString() + "";
                            button2.Enabled = false;
                            if (frm == too)
                            {
                                string res = string.Format(" {0} ", rec.GetValue(9));
                                textBox12.Text = res + "";
                                textBox38.Text = v.ToString() + "";
                                textBox21.Text = v.ToString() + "";
                                string c = string.Format(" {0} ", rec.GetValue(10));
                                textBox13.Text = c + "";
                                textBox37.Text = v.ToString() + "";
                                textBox22.Text = v.ToString() + "";
                                string d = string.Format(" {0} ", rec.GetValue(11));
                                textBox14.Text = d + "";
                                textBox36.Text = v.ToString() + "";
                                textBox23.Text = v.ToString() + "";
                                string f = string.Format(" {0} ", rec.GetValue(12));
                                textBox16.Text = f + "";
                                textBox34.Text = v.ToString() + "";
                                textBox25.Text = v.ToString() + "";
                                string g = string.Format(" {0} ", rec.GetValue(13));
                                textBox17.Text = g + "";
                                textBox33.Text = v.ToString() + "";
                                textBox26.Text = v.ToString() + "";
                                string h = string.Format(" {0} ", rec.GetValue(14));
                                textBox18.Text = h + "";
                                textBox32.Text = v.ToString() + "";
                                textBox27.Text = v.ToString() + "";
                                string i = string.Format(" {0} ", rec.GetValue(15));
                                textBox19.Text = i + "";
                                textBox31.Text = v.ToString() + "";
                                textBox28.Text = v.ToString() + "";
                                string j = string.Format(" {0} ", rec.GetValue(16));
                                textBox20.Text = j + "";
                                textBox30.Text = v.ToString() + "";
                                textBox29.Text = v.ToString() + "";
                                rec.Close();

                            }

                            else
                            {
                                rec.Close();

                                int sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select reservationfee from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        string s = string.Format(" {0} ", rec1.GetValue(0));
                                        int su = int.Parse(s);
                                        sum = sum + su;
                                        rec1.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }

                                }
                                textBox12.Text = sum.ToString();
                                textBox38.Text = v.ToString() + "";
                                textBox21.Text = v.ToString() + "";
                                sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select rent from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();
                                    if (rec1.Read())
                                    {
                                        string s1 = string.Format(" {0} ", rec1.GetValue(0));
                                        int su1 = int.Parse(s1);
                                        sum = sum + su1;
                                        rec1.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }
                                }
                                textBox13.Text = sum.ToString();
                                textBox37.Text = v.ToString() + "";
                                textBox22.Text = v.ToString() + "";
                                sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select charge50 from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();
                                    if (rec1.Read())
                                    {
                                        string s2 = string.Format(" {0} ", rec1.GetValue(0));
                                        int su2 = int.Parse(s2);
                                        sum = sum + su2;
                                        rec1.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }
                                }
                                textBox14.Text = sum.ToString();
                                textBox36.Text = v.ToString() + "";
                                textBox23.Text = v.ToString() + "";
                                sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select charge25 from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();
                                    if (rec1.Read())
                                    {
                                        string s3 = string.Format(" {0} ", rec1.GetValue(0));
                                        int su3 = int.Parse(s3);
                                        sum = sum + su3;
                                        rec1.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }
                                }
                                textBox16.Text = sum.ToString();
                                textBox34.Text = v.ToString() + "";
                                textBox25.Text = v.ToString() + "";
                                sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select charge15 from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();
                                    if (rec1.Read())
                                    {
                                        string s5 = string.Format(" {0} ", rec1.GetValue(0));
                                        int su5 = int.Parse(s5);
                                        sum = sum + su5;
                                        rec1.Close();
                                    }

                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }

                                }
                                textBox17.Text = sum.ToString();
                                textBox33.Text = v.ToString() + "";
                                textBox26.Text = v.ToString() + "";
                                sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select lastyear from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();
                                    if (rec1.Read())
                                    {
                                        string s6 = string.Format(" {0} ", rec1.GetValue(0));
                                        int su6 = int.Parse(s6);
                                        sum = sum + su6;
                                        rec1.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }

                                }
                                textBox18.Text = sum.ToString();
                                textBox32.Text = v.ToString() + "";
                                textBox27.Text = v.ToString() + "";

                                sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select coveredcharge from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();
                                    if (rec1.Read())
                                    {
                                        string s7 = string.Format(" {0} ", rec1.GetValue(0));
                                        int su7 = int.Parse(s7);
                                        sum = sum + su7;
                                        rec1.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }

                                }
                                textBox19.Text = sum.ToString();
                                textBox31.Text = v.ToString() + "";
                                textBox28.Text = v.ToString() + "";

                                sum = 0;
                                for (int i = frm; i <= too; i++)
                                {

                                    Name = string.Format("Select other from Shopfee where shopnofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();
                                    if (rec1.Read())
                                    {
                                        string s8 = string.Format(" {0} ", rec1.GetValue(0));
                                        int su8 = int.Parse(s8);
                                        sum = sum + su8;
                                        rec1.Close();
                                    }
                                    else
                                    {
                                        MessageBox.Show("no record");
                                    }
                                }
                                textBox20.Text = sum.ToString();
                                textBox30.Text = v.ToString() + "";
                                textBox29.Text = v.ToString() + "";
                            }
                            a = 0;



                            rec.Close();


                           

                        }
                        else
                        {
                            MessageBox.Show("no record");

                        }
                        if (no3 > 0 && no4 > 0)
                        {

                            int a1 = int.Parse(textBox12.Text);
                            int a2 = int.Parse(textBox13.Text);
                            int a3 = int.Parse(textBox14.Text);
                            int a4 = int.Parse(textBox16.Text);
                            int a5 = int.Parse(textBox17.Text);
                            int a6 = int.Parse(textBox18.Text);
                            int a7 = int.Parse(textBox19.Text);
                            int a8 = int.Parse(textBox20.Text);

                            if (no3 == no4)
                            {

                                Name = string.Format("Select * from Storefee where storenofrom ={0} ", no3);
                                cmd = new SqlCommand(Name, cn);
                                rec = cmd.ExecuteReader();
                                if (rec.Read())
                                {

                                    int res = int.Parse(string.Format(" {0} ", rec.GetValue(1)));
                                    a1 = a1 + res;
                                    textBox12.Text = a1.ToString();

                                    int res1 = int.Parse(string.Format(" {0} ", rec.GetValue(2)));
                                    a2 = a2 + res1;
                                    textBox13.Text = a2.ToString();

                                    int res2 = int.Parse(string.Format(" {0} ", rec.GetValue(3)));
                                    a3 = a3 + res2;
                                    textBox14.Text = a3.ToString();

                                    int res3 = int.Parse(string.Format(" {0} ", rec.GetValue(4)));
                                    a4 = a4 + res3;
                                    textBox16.Text = a4.ToString();

                                    int res4 = int.Parse(string.Format(" {0} ", rec.GetValue(5)));
                                    a5 = a5 + res4;
                                    textBox17.Text = a5.ToString();

                                    int res5 = int.Parse(string.Format(" {0} ", rec.GetValue(6)));
                                    a6 = a6 + res5;
                                    textBox18.Text = a6.ToString();

                                    int res6 = int.Parse(string.Format(" {0} ", rec.GetValue(7)));
                                    a7 = a7 + res6;
                                    textBox19.Text = a7.ToString();

                                    int res7 = int.Parse(string.Format(" {0} ", rec.GetValue(8)));
                                    a8 = a8 + res7;
                                    textBox20.Text = a8.ToString();
                                    rec.Close();

                                }

                            }

                            else
                            {


                                int sum = 0;
                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select reservationfee from Storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a1 = a1 + sum;
                                textBox12.Text = a1.ToString();
                                sum = 0;

                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select rent from Storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a2 = a2 + sum;
                                textBox13.Text = a2.ToString();
                                sum = 0;

                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select charge50 from Storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a3 = a3 + sum;
                                textBox14.Text = a3.ToString();
                                sum = 0;

                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select charge25 from storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a4 = a4 + sum;
                                textBox16.Text = a4.ToString();
                                sum = 0;

                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select charge15 from Storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a5 = a5 + sum;
                                textBox17.Text = a5.ToString();
                                sum = 0;

                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select lastyear from Storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a6 = a6 + sum;
                                textBox18.Text = a6.ToString();
                                sum = 0;

                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select coveredcharge from Storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a7 = a7 + sum;
                                textBox19.Text = a7.ToString();
                                sum = 0;

                                for (int i = no3; i <= no4; i++)
                                {

                                    Name = string.Format("Select other from Storefee where storenofrom ={0} ", i);
                                    cmd = new SqlCommand(Name, cn);
                                    SqlDataReader rec1 = cmd.ExecuteReader();

                                    if (rec1.Read())
                                    {
                                        int s = int.Parse(string.Format(" {0} ", rec1.GetValue(0)));

                                        sum = sum + s;
                                        rec1.Close();
                                    }

                                }
                                a8 = a8 + sum;
                                textBox20.Text = a8.ToString();



                            }




                        }



                        cn.Close();
                        




                    }

                    else
                    {
                        MessageBox.Show("Record not found");

                    }

                }


                else
                {
                    
                    textBox2.Text = "";
                    MessageBox.Show("Record not found");
                }
                    
                
                
            }
            catch(Exception t)
            {
                MessageBox.Show(t.Message);
            }
        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        

        private void button4_Click(object sender, EventArgs e)
        {
            
            try
            { int xy = 0;
                int due = int.Parse(textBox41.Text);
                if (due >0)
                {
                    int a = int.Parse(textBox12.Text);
                    int j = int.Parse(textBox21.Text);
                    int r = int.Parse(textBox38.Text);
                    if (j <= a && j >= 0)
                    {
                        r = a - j;
                        textBox38.Text = r.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox21.Text = xy.ToString() + "";
                        j = int.Parse(textBox21.Text);
                        textBox38.Text = xy.ToString() + "";
                        r = int.Parse(textBox38.Text);
                    }
                    int b = int.Parse(textBox13.Text);
                    int k = int.Parse(textBox22.Text);
                    int s = int.Parse(textBox37.Text);
                    if (k <= b && k >= 0)
                    {

                        s = b - k;
                        textBox37.Text = s.ToString();
                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox22.Text = xy.ToString() + "";
                        k = int.Parse(textBox22.Text);
                        textBox37.Text = xy.ToString() + "";
                        s = int.Parse(textBox37.Text);

                    }
                    int c = int.Parse(textBox14.Text);
                    int l = int.Parse(textBox23.Text);
                    int t = int.Parse(textBox36.Text);
                    if (l <= c && l >= 0)
                    {
                        t = c - l;
                        textBox36.Text = t.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox23.Text = xy.ToString() + "";
                        l = int.Parse(textBox23.Text);
                        textBox36.Text = xy.ToString() + "";
                        t = int.Parse(textBox36.Text);
                    }
                    int d = int.Parse(textBox16.Text);
                    int m = int.Parse(textBox25.Text);
                    int u = int.Parse(textBox34.Text);
                    if (m <= d && m >= 0)
                    {
                        u = d - m;
                        textBox34.Text = u.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox25.Text = xy.ToString() + "";
                        m = int.Parse(textBox25.Text);
                        textBox34.Text = xy.ToString() + "";
                        u = int.Parse(textBox34.Text);
                    }
                    int i = int.Parse(textBox17.Text);
                    int n = int.Parse(textBox26.Text);
                    int v = int.Parse(textBox33.Text);
                    if (n <= i && n >= 0)
                    {
                        v = i - n;
                        textBox33.Text = v.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox26.Text = xy.ToString() + "";
                        n = int.Parse(textBox26.Text);
                        textBox33.Text = xy.ToString() + "";
                        v = int.Parse(textBox33.Text);
                    }

                    int f = int.Parse(textBox18.Text);
                    int o = int.Parse(textBox27.Text);
                    int w = int.Parse(textBox32.Text);
                    if (o <= f && o >= 0)
                    {
                        w = f - o;
                        textBox32.Text = w.ToString();
                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox27.Text = xy.ToString() + "";
                        o = int.Parse(textBox27.Text);
                        textBox32.Text = xy.ToString() + "";
                        w = int.Parse(textBox32.Text);
                    }
                    int g = int.Parse(textBox19.Text);
                    int p = int.Parse(textBox28.Text);
                    int x = int.Parse(textBox31.Text);
                    if (p <= g && p >= 0)
                    {
                        x = g - p;
                        textBox31.Text = x.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox28.Text = xy.ToString() + "";
                        p = int.Parse(textBox28.Text);
                        textBox31.Text = xy.ToString() + "";
                        x = int.Parse(textBox31.Text);
                    }

                    int h = int.Parse(textBox20.Text);
                    int q = int.Parse(textBox29.Text);
                    int y = int.Parse(textBox30.Text);
                    if (q <= h && q >= 0)
                    {
                        y = h - q;
                        textBox30.Text = y.ToString();
                    }

                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox29.Text = xy.ToString() + "";
                        q = int.Parse(textBox29.Text);
                        textBox30.Text = xy.ToString() + "";
                        y = int.Parse(textBox30.Text);
                    }
                    int sum = a + b + c + d + i + f + g + h;
                    textBox40.Text = sum.ToString();


                    int sum1 = j + k + l + m + n + o + p + q;
                    textBox41.Text = sum1.ToString();


                    int sum2 = r + s + t + u + v + w + x + y;
                    textBox42.Text = sum2.ToString();
                    button2.Enabled = false;
           
                    button6.Enabled = true;
                }
                else
                {
                    int a = int.Parse(textBox12.Text);
                    int j = int.Parse(textBox21.Text);
                    int r = int.Parse(textBox38.Text);
                    if (j <= a && j >= 0)
                    {
                        r = a - j;
                        textBox38.Text = r.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox21.Text = xy.ToString() + "";
                        j = int.Parse(textBox21.Text);
                        textBox38.Text = xy.ToString() + "";
                        r = int.Parse(textBox38.Text);
                    }
                    int b = int.Parse(textBox13.Text);
                    int k = int.Parse(textBox22.Text);
                    int s = int.Parse(textBox37.Text);
                    if (k <= b && k >= 0)
                    {

                        s = b - k;
                        textBox37.Text = s.ToString();
                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox22.Text = xy.ToString() + "";
                        k = int.Parse(textBox22.Text);
                        textBox37.Text = xy.ToString() + "";
                        s = int.Parse(textBox37.Text);

                    }
                    int c = int.Parse(textBox14.Text);
                    int l = int.Parse(textBox23.Text);
                    int t = int.Parse(textBox36.Text);
                    if (l <= c && l >= 0)
                    {
                        t = c - l;
                        textBox36.Text = t.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox23.Text = xy.ToString() + "";
                        l = int.Parse(textBox23.Text);
                        textBox36.Text = xy.ToString() + "";
                        t = int.Parse(textBox36.Text);
                    }
                    int d = int.Parse(textBox16.Text);
                    int m = int.Parse(textBox25.Text);
                    int u = int.Parse(textBox34.Text);
                    if (m <= d && m >= 0)
                    {
                        u = d - m;
                        textBox34.Text = u.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox25.Text = xy.ToString() + "";
                        m = int.Parse(textBox25.Text);
                        textBox34.Text = xy.ToString() + "";
                        u = int.Parse(textBox34.Text);
                    }
                    int i = int.Parse(textBox17.Text);
                    int n = int.Parse(textBox26.Text);
                    int v = int.Parse(textBox33.Text);
                    if (n <= i && n >= 0)
                    {
                        v = i - n;
                        textBox33.Text = v.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox26.Text = xy.ToString() + "";
                        n = int.Parse(textBox26.Text);
                        textBox33.Text = xy.ToString() + "";
                        v = int.Parse(textBox33.Text);
                    }

                    int f = int.Parse(textBox18.Text);
                    int o = int.Parse(textBox27.Text);
                    int w = int.Parse(textBox32.Text);
                    if (o <= f && o >= 0)
                    {
                        w = f - o;
                        textBox32.Text = w.ToString();
                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox27.Text = xy.ToString() + "";
                        o = int.Parse(textBox27.Text);
                        textBox32.Text = xy.ToString() + "";
                        w = int.Parse(textBox32.Text);
                    }
                    int g = int.Parse(textBox19.Text);
                    int p = int.Parse(textBox28.Text);
                    int x = int.Parse(textBox31.Text);
                    if (p <= g && p >= 0)
                    {
                        x = g - p;
                        textBox31.Text = x.ToString();

                    }
                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox28.Text = xy.ToString() + "";
                        p = int.Parse(textBox28.Text);
                        textBox31.Text = xy.ToString() + "";
                        x = int.Parse(textBox31.Text);
                    }

                    int h = int.Parse(textBox20.Text);
                    int q = int.Parse(textBox29.Text);
                    int y = int.Parse(textBox30.Text);
                    if (q <= h && q >= 0)
                    {
                        y = h - q;
                        textBox30.Text = y.ToString();
                    }

                    else
                    {

                        MessageBox.Show("Incorrect paying amount please check");
                        textBox29.Text = xy.ToString() + "";
                        q = int.Parse(textBox29.Text);
                        textBox30.Text = xy.ToString() + "";
                        y = int.Parse(textBox30.Text);
                    }
                    int sum = a + b + c + d + i + f + g + h;
                    textBox40.Text = sum.ToString();


                    int sum1 = j + k + l + m + n + o + p + q;
                    textBox41.Text = sum1.ToString();


                    int sum2 = r + s + t + u + v + w + x + y;
                    textBox42.Text = sum2.ToString();
                    button2.Enabled = true;
                    button6.Enabled = false;
                        

                }
            }
            catch (Exception tf)
            {
                MessageBox.Show("please fill empty entry");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {


            try
            {

                string dat = dateTimePicker1.Text;
                string name = textBox1.Text;
                
                
                string fname = textBox2.Text;
                string address = textBox3.Text;
                string year = textBox4.Text;
                string block = textBox7.Text;
                int from = int.Parse(textBox8.Text);
                int to = int.Parse(textBox9.Text);
                int from1 = int.Parse(textBox44.Text);
                int to1 = int.Parse(textBox43.Text);
                int total = int.Parse(textBox10.Text);
                string type = textBox11.Text;

                int c = int.Parse(textBox12.Text);
                int d = int.Parse(textBox13.Text);
                int f= int.Parse(textBox14.Text);
                int  g= int.Parse(textBox16.Text);
                int  h= int.Parse(textBox17.Text);
                int i = int.Parse(textBox18.Text);
                int j = int.Parse(textBox19.Text);
                int k = int.Parse(textBox20.Text);
                int t = int.Parse(textBox40.Text);

                int c1 = int.Parse(textBox21.Text);
                int d1 = int.Parse(textBox22.Text);
                int f1 = int.Parse(textBox23.Text);
                int g1 = int.Parse(textBox25.Text);
                int h1 = int.Parse(textBox26.Text);
                int i1 = int.Parse(textBox27.Text);
                int j1 = int.Parse(textBox28.Text);
                int k1 = int.Parse(textBox29.Text);
                int t1 = int.Parse(textBox41.Text);

                int c2 = int.Parse(textBox38.Text);
                int d2 = int.Parse(textBox37.Text);
                int f2 = int.Parse(textBox36.Text);
                int g2 = int.Parse(textBox34.Text);
                int h2 = int.Parse(textBox33.Text);
                int i2 = int.Parse(textBox32.Text);
                int j2 = int.Parse(textBox31.Text);
                int k2 = int.Parse(textBox30.Text);
                int t2 = int.Parse(textBox42.Text);
                
               
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string query = string.Format("insert into Reservation values('{0}','{1}','{2}','{3}','{4}','{5}',{6},{7},{8},'{9}',{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},{28},{29},{30},{31},{32},{33},{34},{35},{36},{37},{38})",dat,name,fname,address,year,block,from,to,total,type,c,d,f,g,h,i,j,k,t,c1,d1,f1,g1,h1,i1,j1,k1,t1,c2,d2,f2,g2,h2,i2,j2,k2,t2,from1,to1);
               
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                for (int m = from; m <= to; m++)
                {
                    query = string.Format("update shopstatus set name=N'{1}',status='Reserved' where shopnofrom={0}",m,name);
                    cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();

                }
                for (int m = from1; m <= to1; m++)
                {
                    query = string.Format("update storestatus set name=N'{1}',status='Reserved' where storenofrom={0}", m, name);
                    cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();

                }
                MessageBox.Show("Record submitted ....");
                button5.Enabled = true;
                cn.Close();

            }
            catch (Exception gh)
            {

                MessageBox.Show(gh.Message);

            }







        }

        private void Form3_Load(object sender, EventArgs e)
        {
            button2.Enabled = false;
            button5.Enabled = false;
            button6.Enabled = false;
            int a = 0;
            textBox35.Text = a.ToString();
            textBox39.Text = a.ToString();
            textBox44.Text = a.ToString();
            textBox43.Text = a.ToString();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PrintScreen();
            printPreviewDialog1.ShowDialog();
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;

        private void PrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                string year = textBox4.Text.TrimStart();

                int from = int.Parse(textBox8.Text);
                int to = int.Parse(textBox9.Text);

                int c1 = int.Parse(textBox21.Text);
                int d1 = int.Parse(textBox22.Text);
                int f1 = int.Parse(textBox23.Text);
                int g1 = int.Parse(textBox25.Text);
                int h1 = int.Parse(textBox26.Text);
                int i1 = int.Parse(textBox27.Text);
                int j1 = int.Parse(textBox28.Text);
                int k1 = int.Parse(textBox29.Text);
                int t1 = int.Parse(textBox41.Text);

                int c2 = int.Parse(textBox38.Text);
                int d2 = int.Parse(textBox37.Text);
                int f2 = int.Parse(textBox36.Text);
                int g2 = int.Parse(textBox34.Text);
                int h2 = int.Parse(textBox33.Text);
                int i2 = int.Parse(textBox32.Text);
                int j2 = int.Parse(textBox31.Text);
                int k2 = int.Parse(textBox30.Text);
                int t2 = int.Parse(textBox42.Text);

                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();

               string query1 = string.Format("update Reservation set paidreservation={3},paidrent={4},paidcharge50={5},paidcharge25={6},paidcharge15={7},paidlastyear={8},paidcoveredcharge={9},paidother={10},paidtotal={11} where shopnofrom={0} and shopnoto={1} and year=' {2}'", from,to,year,c1,d1,f1,g1,h1,i1,j1,k1,t1);
                SqlCommand cmd = new SqlCommand(query1, cn);
               
                
                    cmd.ExecuteNonQuery();
                query1 = string.Format("update Reservation set duereservation={3},duerent={4},duecharge50={5},duecharge25={6},duecharge15={7},duelastyear={8},duecoveredcharge={9},dueother={10},duetotal={11} where shopnofrom={0} and shopnoto={1} and year=' {2}'", from, to, year, c2, d2, f2, g2, h2, i2, j2, k2, t2);
                cmd = new SqlCommand(query1, cn);
              
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");

            }
            catch (Exception g)
            {

                MessageBox.Show(g.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox42_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox30_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox31_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox32_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox33_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox34_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox36_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox37_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox38_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox41_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox29_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox28_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox27_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox26_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox25_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox40_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox20_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void label21_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {

        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void label31_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }
    }
   
}
