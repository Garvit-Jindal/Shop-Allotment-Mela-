﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string user = textBox1.Text;
                long   pass = long.Parse(textBox2.Text);
                if (user == "mela" && pass == 789456123000)
                {

                   
                        SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                        cn.Open();
                        for (int i = 1; i <= 160; i++)
                        {
                            string query = string.Format("Update storestatus set status='UnReserved',name ='NULL' where storenofrom={0}", i);

                            SqlCommand cmd = new SqlCommand(query, cn);
                            cmd.ExecuteNonQuery();


                        }
                        MessageBox.Show("Record updated");
                        cn.Close();
                    
                 


                }
                else
                {
                    MessageBox.Show("wrong password");
                }

            }
            catch (Exception g)
            {

            }
        }
    }
}
