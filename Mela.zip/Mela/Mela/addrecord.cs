﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class addrecord : Form
    {
        public addrecord()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int no = int.Parse(textBox9.Text);
                int res = int.Parse(textBox1.Text);
                int rent = int.Parse(textBox2.Text);
                int per50 = int.Parse(textBox3.Text);
                int per25 = int.Parse(textBox4.Text);
                int per15 = int.Parse(textBox5.Text);
                int ly = int.Parse(textBox6.Text);
                int ccharge = int.Parse(textBox7.Text);
                int oth = int.Parse(textBox8.Text);
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string query = string.Format("insert into Shopfee values({0},{1},{2},{3},{4},{5},{6},{7},{8})", no,res,rent,per50,per25,per15,ly,ccharge,oth);
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record submitted ....");
                cn.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show(a.Message);

            }
        }
    }
}
