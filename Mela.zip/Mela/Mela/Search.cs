﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
namespace Mela
{
    public partial class Search : Form
    {
        
        public Search()
        {
            InitializeComponent();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = Form1.set1;
                textBox2.Text = Form1.set2;
                textBox3.Text = Form1.set3;
                textBox4.Text = Form1.set4;
                textBox5.Text = Form1.set5;
                textBox6.Text = Form1.set6;
                textBox8.Text = Form1.set13;
                textBox7.Text = Form1.set14;
                int id = Form1.set11;
                checkBox1.Checked = false;
                checkBox2.Checked = false;
               // checkBox3.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
                checkBox1.Enabled = false;
                checkBox2.Enabled = false;
                //checkBox3.Enabled = false;
                checkBox4.Enabled = false;
                checkBox5.Enabled = false;
                checkBox6.Enabled = false;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                MemoryStream stream = new MemoryStream();
                cn.Open();

                string Name = string.Format("  Select image from pic where id={0} ", id);
                SqlCommand cmd = new SqlCommand(Name, cn);
                byte[] image = (byte[])cmd.ExecuteScalar();
                stream.Write(image, 0, image.Length);
                cn.Close();
                Bitmap bitmap = new Bitmap(stream);
                pictureBox1.Image = bitmap;


                

            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void Search_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Do you really want to exit??", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                Search f1 = new Search();
                f1.Close();

            
            }

            else
            {
                e.Cancel = true;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int a = Form1.set7;
            if (a == 1)
            {

                checkBox1.Checked = true;

            }
            else
            {
                checkBox1.Checked = false;

            }

            int b = Form1.set8;
            if (b == 1)
            {

                checkBox2.Checked = true;

            }
            else
            {
                checkBox2.Checked = false;

            }


           /* int c = Form1.set9;
            if (c == 1)
            {

                checkBox3.Checked = true;

            }
            else
            {
                checkBox3.Checked = false;

            }
            */
            int d = Form1.set10;
            if (d == 1)
            {

                checkBox4.Checked = true;


            }
            else
            {
                checkBox4.Checked = false;

            }

            int i = Form1.set11;
            if (i == 1)
            {

                checkBox5.Checked = true;


            }
            else
            {
                checkBox5.Checked = false;

            }

            int f = Form1.set12;
            if (f == 1)
            {

                checkBox6.Checked = true;


            }
            else
            {
                checkBox6.Checked = false;

            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
