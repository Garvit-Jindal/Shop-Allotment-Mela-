﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                

                    int a = 1;
                    int b = 0;
                    int no = int.Parse(textBox7.Text);
                    int no1 = int.Parse(textBox12.Text);
                    int no3 = int.Parse(textBox23.Text);
                    int no4 = int.Parse(textBox22.Text);

                string year1 = textBox13.Text.TrimStart();

                    if (no > 0)
                    {
                        SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                        cn.Open();

                    string Name = string.Format("  Select * from Extraarea where shopnofrom={0} and shopnoto={1} and year='  {2}' and storenofrom={3} and storenoto={4} ", no,no1,year1,no3,no4);
                    
                    SqlCommand cmd = new SqlCommand(Name, cn);

                    SqlDataReader rec = cmd.ExecuteReader();

                    if (rec.Read())
                    {

                        string date = string.Format(" {0} ", rec.GetValue(0));
                        dateTimePicker1.Text = date + "";

                        string name = string.Format(" {0} ", rec.GetValue(1));
                        textBox1.Text = name + "";

                        string fname = string.Format(" {0} ", rec.GetValue(2));
                        textBox2.Text = fname + "";

                        string from = string.Format(" {0} ", rec.GetValue(3));
                        textBox3.Text = from + "";

                        string to = string.Format(" {0} ", rec.GetValue(4));
                        textBox4.Text = to + "";

                        string block = string.Format(" {0} ", rec.GetValue(5));
                        textBox5.Text = block + "";

                        string year = string.Format(" {0} ", rec.GetValue(6));
                        textBox6.Text = year + "";

                        string sarea = string.Format(" {0} ", rec.GetValue(7));
                        textBox8.Text = sarea + "";

                        string srate = string.Format(" {0} ", rec.GetValue(8));
                        textBox9.Text = srate + "";

                        string stotal = string.Format(" {0} ", rec.GetValue(9));
                        textBox20.Text = stotal + "";

                        string garea = string.Format(" {0} ", rec.GetValue(10));
                        textBox11.Text = garea + "";

                        string grate = string.Format(" {0} ", rec.GetValue(11));
                        textBox10.Text = grate + "";

                        string gtotal = string.Format(" {0} ", rec.GetValue(12));
                        textBox21.Text = gtotal + "";

                        string total = string.Format(" {0} ", rec.GetValue(13));
                        textBox14.Text = total + "";

                        string total15 = string.Format(" {0} ", rec.GetValue(14));
                        textBox15.Text = total15 + "";

                        string total1 = string.Format(" {0} ", rec.GetValue(15));
                        textBox16.Text = total1 + "";

                        string paidtotal = string.Format(" {0} ", rec.GetValue(16));
                        textBox17.Text = paidtotal + "";
                        int paid = int.Parse(paidtotal);
                        string date1 = string.Format(" {0} ", rec.GetValue(17));
                        dateTimePicker2.Text = date1 + "";

                        string duetotal = string.Format(" {0} ", rec.GetValue(18));
                        textBox18.Text = duetotal + "";
                        textBox19.Text = duetotal + "";
                        int store = int.Parse(string.Format(" {0} ", rec.GetValue(19)));
                        textBox25.Text = store.ToString();
                    

                        int store1 = int.Parse(string.Format(" {0} ", rec.GetValue(20)));
                        textBox24.Text = store1.ToString();
                        button4.Enabled = true;
                        int due = int.Parse(duetotal);
                        if (due > 0)
                        {
                            MessageBox.Show("You have paid  " + paid + " Rs please pay rest  " + due + "  Rs");
                        }

                        else if (due == 0)
                        {
                            MessageBox.Show("You have paid  " + paid + " Rs  and their is no due");

                        }
                        a = 0;
                        button3.Enabled = true;
                        button2.Enabled = false;
                    }

                    else if (a == 1)
                    {
                        rec.Close();
                         Name = string.Format("  Select name,fname,shopnofrom ,shopnoto,block,year,storenofrom,storenoto from Reservation where shopnofrom={0} and shopnoto={1} and year=' {2}' and storenofrom={3} and storenoto={4}", no,no1,year1,no3,no4);
                         cmd = new SqlCommand(Name, cn);
                         rec = cmd.ExecuteReader();

                        if (rec.Read())
                        {

                            string name = string.Format(" {0} ", rec.GetValue(0));
                            textBox1.Text = name + "";
                            string fname = string.Format(" {0} ", rec.GetValue(1));
                            textBox2.Text = fname + "";
                            string from = string.Format(" {0} ", rec.GetValue(2));
                            textBox3.Text = from + "";
                            string too = string.Format(" {0} ", rec.GetValue(3));
                            textBox4.Text = too + "";
                            string block = string.Format(" {0} ", rec.GetValue(4));
                            textBox5.Text = block;
                            string year = string.Format(" {0} ", rec.GetValue(5));
                            textBox6.Text = year + "";
                            int store = int.Parse(string.Format(" {0} ", rec.GetValue(6)));
                            textBox25.Text = store.ToString();
                            int store1= int.Parse(string.Format(" {0} ", rec.GetValue(7)));
                            textBox24.Text = store1.ToString();

                            rec.Close();
                            string block1 = textBox5.Text.TrimStart();

                            string Name1 = string.Format("Select * from Extra where block='{0}'", block1);
                            SqlCommand cmd1 = new SqlCommand(Name1, cn);
                            rec = cmd1.ExecuteReader();
                            if (rec.Read())
                            {

                                textBox8.Text = b.ToString();
                                textBox20.Text = b.ToString();
                                textBox11.Text = b.ToString();
                                textBox21.Text = b.ToString();
                                textBox14.Text = b.ToString();
                                textBox15.Text = b.ToString();
                                textBox16.Text = b.ToString();
                                textBox17.Text = b.ToString();
                                textBox18.Text = b.ToString();

                                string srate = string.Format(" {0} ", rec.GetValue(1));
                                textBox9.Text = srate + "";
                                string s1rate = string.Format(" {0} ", rec.GetValue(2));
                                textBox10.Text = s1rate + "";
                                rec.Close();

                            }
                            else
                            {
                                MessageBox.Show("please insert rates from admin panel");
                            }

                            a = 0;
                        }

                        else
                        {
                            MessageBox.Show("no record found ");

                        }

                    }
                    
                    
                    else
                    {

                        MessageBox.Show("no record found at shop = " + no);
                    }


                    }
                    else
                    {
                        MessageBox.Show("no record found at shop = " + no);
                    }
                
                


            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                int area = int.Parse(textBox8.Text);
                int rate= int.Parse(textBox9.Text);
                int total = area * rate;
                textBox20.Text = total.ToString();


                int area1 = int.Parse(textBox11.Text);
                int rate1 = int.Parse(textBox10.Text);
                int total1 = area1 * rate1;
                textBox21.Text = total1.ToString();


                int full = total + total1;
                textBox14.Text = full.ToString();


                float total15 = (full * 15)/100;
                textBox15.Text = total15.ToString();


                float full1 = full + total15;
                textBox16.Text = full1.ToString();


                

            }
            catch (Exception g)
            {

                MessageBox.Show(g.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string date = dateTimePicker1.Text;
                string name = textBox1.Text;
                string fname = textBox2.Text;
                int from = int.Parse(textBox3.Text);
                int to = int.Parse(textBox4.Text);
                string block = textBox5.Text;
                string year = textBox6.Text;
                int sarea = int.Parse(textBox8.Text);
                int srate = int.Parse(textBox9.Text);
                int stotal = int.Parse(textBox20.Text);
                int garea = int.Parse(textBox11.Text);
                int grate = int.Parse(textBox10.Text);
                int gtotal = int.Parse(textBox21.Text);
                int total = int.Parse(textBox14.Text);
                int total15 = int.Parse(textBox15.Text);
                int total1 = int.Parse(textBox16.Text);
                int paidtotal = int.Parse(textBox17.Text);
                string date1 = dateTimePicker2.Text;
                int duetotal = int.Parse(textBox18.Text);
                int store = int.Parse(textBox25.Text);
                int store1 = int.Parse(textBox24.Text);


                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string query = string.Format("insert into Extraarea values('{0}','{1}','{2}',{3},{4},'{5}','{6}',{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},'{17}',{18},{19},{20})", date, name, fname,from,to,block,year,sarea,srate,stotal,garea,grate,gtotal,total,total15,total1,paidtotal,date1,duetotal,store,store1);
                SqlCommand cmd = new SqlCommand(query, cn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record submitted ....");
                cn.Close();
                button4.Enabled = true;

            }
            catch(Exception g)
            {

                MessageBox.Show(g.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                int paid = int.Parse(textBox17.Text);
                int due = int.Parse(textBox18.Text);
                int from = int.Parse(textBox3.Text);
                int to = int.Parse(textBox4.Text);
                string y = textBox6.Text.TrimStart();
                int total1 = int.Parse(textBox16.Text);
                if (paid <= total1)
                {
                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();
                    string query = string.Format("update Extraarea set paidtotal={0},duetotal={1} where shopnofrom={2} and year='  {4}'", paid, due, from,to,y);
                    SqlCommand cmd = new SqlCommand(query, cn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record updated ....");
                    cn.Close();
                }

                else if (paid > total1)
                {

                    MessageBox.Show("wrong paying amount please check ");


                }

            }
            catch(Exception g)
            {
                MessageBox.Show(g.Message);

            }

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            button3.Enabled = false;
            int a = 0;
            textBox23.Text = a.ToString();
            textBox22.Text = a.ToString();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern long BitBlt(IntPtr hdcDest, int nXDest, int nYDest, int nWidth, int nHeight, IntPtr hdcSrc, int nXSrc, int nYSrc, int dwRop);
        private Bitmap memoryImage;
        private void PrintScreen()
        {
            Graphics mygraphics = this.CreateGraphics();
            Size s = this.Size;
            memoryImage = new Bitmap(s.Width, s.Height, mygraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            IntPtr dc1 = mygraphics.GetHdc();
            IntPtr dc2 = memoryGraphics.GetHdc();
            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            mygraphics.ReleaseHdc(dc1);
            memoryGraphics.ReleaseHdc(dc2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            PrintScreen();
            printPreviewDialog1.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                int full1 = int.Parse(textBox16.Text);
                int paidtotal = int.Parse(textBox17.Text);
                float duetotal = full1 - paidtotal;
                textBox18.Text = duetotal.ToString();
                textBox19.Text = duetotal.ToString();
                MessageBox.Show("Alert : Please pay  " + duetotal + "  Rs as soon as possible ");
            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
            }
            
    }
}
