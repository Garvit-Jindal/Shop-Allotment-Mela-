﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Mela
{
    public partial class admin1 : Form
    {
        public static string set1 = "";
        public static string set2 = "";
        public static string set3 = "";
        public static string set4 = "";
        public static string set5 = "";
        public admin1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addrecord a = new addrecord();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            blockrate b = new blockrate();
            b.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Bijlikirayarate b = new Bijlikirayarate();
            b.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form10 f = new Form10();
                f.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            kotharikiraya k = new kotharikiraya();
            k.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form9 f = new Form9();
            f.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int a = 0;
            try
            {
                string date = dateTimePicker1.Text;
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                string Name = string.Format("  Select sum(paidtotal) from Reservation where date='{0}' ",date );
                SqlCommand cmd = new SqlCommand(Name, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                {
                    set1 = string.Format(" {0} ", rec.GetValue(0));
                    rec.Close();
                }
                else
                {
                    set1 = a.ToString();
                    rec.Close();
                }
                Name = string.Format("  Select sum(paidtotal) from Extraarea where date='{0}' ", date);
                cmd = new SqlCommand(Name, cn);
                rec = cmd.ExecuteReader();
                if (rec.Read())
                {
                    set2 = string.Format(" {0} ", rec.GetValue(0));
                    rec.Close();
                }
                else
                {
                    set2 = a.ToString();
                    rec.Close();
                }
                Name = string.Format("  Select sum(paid) from Electricity where date='{0}' ", date);
                cmd = new SqlCommand(Name, cn);
                rec = cmd.ExecuteReader();
                if (rec.Read())
                {
                    set3 = string.Format(" {0} ", rec.GetValue(0));
                    rec.Close();
                }
                else
                {
                    set3 = a.ToString();
                    rec.Close();
                }
                Form11 f = new Form11();
                f.Show();


            }
            catch (Exception g)
            {

                MessageBox.Show(g.Message);
            }
        }
    }
}
