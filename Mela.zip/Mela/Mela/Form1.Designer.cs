﻿namespace Mela
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.shopstatusBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.practiceDataSet2 = new Mela.PracticeDataSet2();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.shopstatusTableAdapter = new Mela.PracticeDataSet2TableAdapters.shopstatusTableAdapter();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.button7 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.storestatusBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.practiceDataSet3 = new Mela.PracticeDataSet3();
            this.storestatusTableAdapter = new Mela.PracticeDataSet3TableAdapters.storestatusTableAdapter();
            this.label5 = new System.Windows.Forms.Label();
            this.practiceDataSet4 = new Mela.PracticeDataSet4();
            this.electricityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.electricityTableAdapter = new Mela.PracticeDataSet4TableAdapters.ElectricityTableAdapter();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.noduesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.practiceDataSet5 = new Mela.PracticeDataSet5();
            this.noduesTableAdapter = new Mela.PracticeDataSet5TableAdapters.NoduesTableAdapter();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.electricityBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.practiceDataSet6 = new Mela.PracticeDataSet6();
            this.electricityTableAdapter1 = new Mela.PracticeDataSet6TableAdapters.ElectricityTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.label39 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.button11 = new System.Windows.Forms.Button();
            this.shopnofromDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storenofromDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopnofromDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopnotoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ttotDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storenofromDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storenotoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopnofromDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shopnotoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paidDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storenofromDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storenotoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.shopstatusBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.storestatusBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.noduesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricityBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // shopstatusBindingSource
            // 
            this.shopstatusBindingSource.DataMember = "shopstatus";
            this.shopstatusBindingSource.DataSource = this.practiceDataSet2;
            // 
            // practiceDataSet2
            // 
            this.practiceDataSet2.DataSetName = "PracticeDataSet2";
            this.practiceDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button8
            // 
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(17, 684);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(140, 40);
            this.button8.TabIndex = 19;
            this.button8.Text = "प्रशाशनिक मैनेजर";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(340, 337);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(122, 69);
            this.button6.TabIndex = 17;
            this.button6.Text = "कोई बकाया राशि";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(36, 337);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(130, 69);
            this.button5.TabIndex = 16;
            this.button5.Text = "अतिरिक्त कवर्ड एरिया";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(12, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 29);
            this.label1.TabIndex = 15;
            this.label1.Text = "दुकान नंबर";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(112, 103);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(60, 20);
            this.textBox1.TabIndex = 14;
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(340, 252);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(122, 63);
            this.button4.TabIndex = 13;
            this.button4.Text = "पावती";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(191, 252);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(125, 63);
            this.button3.TabIndex = 12;
            this.button3.Text = "आवंटन आदेश";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(36, 252);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 63);
            this.button2.TabIndex = 11;
            this.button2.Text = "आरक्षण आवेदन पत्र";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(370, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 29);
            this.button1.TabIndex = 10;
            this.button1.Text = " खोजे";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // shopstatusTableAdapter
            // 
            this.shopstatusTableAdapter.ClearBeforeFill = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.Transparent;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton1.Location = new System.Drawing.Point(632, 423);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(114, 33);
            this.radioButton1.TabIndex = 20;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "भरी दुकाने ";
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.Color.Transparent;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton2.Location = new System.Drawing.Point(752, 423);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(126, 33);
            this.radioButton2.TabIndex = 21;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "खाली दुकाने ";
            this.radioButton2.UseVisualStyleBackColor = false;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // button7
            // 
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(191, 337);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(125, 69);
            this.button7.TabIndex = 22;
            this.button7.Text = "बिजली किराया";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(321, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 29);
            this.label2.TabIndex = 23;
            this.label2.Text = "वर्ष";
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Location = new System.Drawing.Point(362, 124);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(178, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 29);
            this.label3.TabIndex = 25;
            this.label3.Text = "से";
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.Location = new System.Drawing.Point(210, 103);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(61, 20);
            this.textBox3.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(277, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 29);
            this.label4.TabIndex = 27;
            this.label4.Text = "तक";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightCoral;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.shopnofromDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.shopstatusBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(632, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(246, 404);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // storestatusBindingSource
            // 
            this.storestatusBindingSource.DataMember = "storestatus";
            this.storestatusBindingSource.DataSource = this.practiceDataSet3;
            // 
            // practiceDataSet3
            // 
            this.practiceDataSet3.DataSetName = "PracticeDataSet3";
            this.practiceDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // storestatusTableAdapter
            // 
            this.storestatusTableAdapter.ClearBeforeFill = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(1111, 486);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(235, 39);
            this.label5.TabIndex = 29;
            this.label5.Text = "बिजली किराया सूचि ";
            // 
            // practiceDataSet4
            // 
            this.practiceDataSet4.DataSetName = "PracticeDataSet4";
            this.practiceDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // electricityBindingSource
            // 
            this.electricityBindingSource.DataMember = "Electricity";
            this.electricityBindingSource.DataSource = this.practiceDataSet4;
            // 
            // electricityTableAdapter
            // 
            this.electricityTableAdapter.ClearBeforeFill = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(251, 486);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(255, 39);
            this.label6.TabIndex = 31;
            this.label6.Text = "पूरा पेमेंट वाली दुकाने ";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToAddRows = false;
            this.dataGridView4.AllowUserToDeleteRows = false;
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.LightCoral;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.shopnofromDataGridViewTextBoxColumn2,
            this.shopnotoDataGridViewTextBoxColumn1,
            this.totalDataGridViewTextBoxColumn,
            this.paidDataGridViewTextBoxColumn1,
            this.storenofromDataGridViewTextBoxColumn2,
            this.storenotoDataGridViewTextBoxColumn1});
            this.dataGridView4.DataSource = this.noduesBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(17, 528);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.Size = new System.Drawing.Size(647, 150);
            this.dataGridView4.TabIndex = 32;
            // 
            // noduesBindingSource
            // 
            this.noduesBindingSource.DataMember = "Nodues";
            this.noduesBindingSource.DataSource = this.practiceDataSet5;
            // 
            // practiceDataSet5
            // 
            this.practiceDataSet5.DataSetName = "PracticeDataSet5";
            this.practiceDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // noduesTableAdapter
            // 
            this.noduesTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.LightCoral;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.shopnofromDataGridViewTextBoxColumn1,
            this.shopnotoDataGridViewTextBoxColumn,
            this.ttotDataGridViewTextBoxColumn,
            this.paidDataGridViewTextBoxColumn,
            this.dueDataGridViewTextBoxColumn,
            this.storenofromDataGridViewTextBoxColumn1,
            this.storenotoDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.electricityBindingSource1;
            this.dataGridView3.Location = new System.Drawing.Point(791, 528);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.Size = new System.Drawing.Size(746, 150);
            this.dataGridView3.TabIndex = 33;
            // 
            // electricityBindingSource1
            // 
            this.electricityBindingSource1.DataMember = "Electricity";
            this.electricityBindingSource1.DataSource = this.practiceDataSet6;
            // 
            // practiceDataSet6
            // 
            this.practiceDataSet6.DataSetName = "PracticeDataSet6";
            this.practiceDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // electricityTableAdapter1
            // 
            this.electricityTableAdapter1.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.LightCoral;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.storenofromDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.storestatusBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(970, 9);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(245, 404);
            this.dataGridView2.TabIndex = 34;
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.Location = new System.Drawing.Point(210, 151);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(61, 20);
            this.textBox4.TabIndex = 38;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label7.Location = new System.Drawing.Point(178, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(27, 29);
            this.label7.TabIndex = 37;
            this.label7.Text = "से";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(2, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 29);
            this.label8.TabIndex = 36;
            this.label8.Text = " कोठरी नंबर";
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.249999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(112, 151);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(60, 20);
            this.textBox5.TabIndex = 35;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(275, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 29);
            this.label9.TabIndex = 39;
            this.label9.Text = "तक";
            // 
            // button9
            // 
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(370, 150);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(82, 29);
            this.button9.TabIndex = 40;
            this.button9.Text = " खोजे";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(510, 94);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(82, 77);
            this.button10.TabIndex = 41;
            this.button10.Text = " दोनों से खोजे";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.BackColor = System.Drawing.Color.Transparent;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton3.Location = new System.Drawing.Point(1098, 420);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(129, 33);
            this.radioButton3.TabIndex = 42;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "खाली  कोठरी";
            this.radioButton3.UseVisualStyleBackColor = false;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.BackColor = System.Drawing.Color.Transparent;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton4.Location = new System.Drawing.Point(970, 420);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(122, 33);
            this.radioButton4.TabIndex = 43;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "भरी  कोठरी ";
            this.radioButton4.UseVisualStyleBackColor = false;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 37F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Teal;
            this.label39.Location = new System.Drawing.Point(42, 9);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(550, 58);
            this.label39.TabIndex = 73;
            this.label39.Text = "ग्वालियर व्यापार मेला प्राधिकरण ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(11, 454);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 31);
            this.label10.TabIndex = 74;
            this.label10.Text = "वर्ष डालें";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(101, 459);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(122, 20);
            this.textBox6.TabIndex = 75;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.BackColor = System.Drawing.Color.Transparent;
            this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton5.Location = new System.Drawing.Point(898, 684);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(118, 33);
            this.radioButton5.TabIndex = 77;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "अधूरा पेमेंट ";
            this.radioButton5.UseVisualStyleBackColor = false;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.BackColor = System.Drawing.Color.Transparent;
            this.radioButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.radioButton6.Location = new System.Drawing.Point(791, 684);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(101, 33);
            this.radioButton6.TabIndex = 76;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "पूरा पेमेंट ";
            this.radioButton6.UseVisualStyleBackColor = false;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // button11
            // 
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(243, 444);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 41);
            this.button11.TabIndex = 78;
            this.button11.Text = "देखे ";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // shopnofromDataGridViewTextBoxColumn
            // 
            this.shopnofromDataGridViewTextBoxColumn.DataPropertyName = "shopnofrom";
            this.shopnofromDataGridViewTextBoxColumn.HeaderText = "Shop no.";
            this.shopnofromDataGridViewTextBoxColumn.Name = "shopnofromDataGridViewTextBoxColumn";
            this.shopnofromDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // storenofromDataGridViewTextBoxColumn
            // 
            this.storenofromDataGridViewTextBoxColumn.DataPropertyName = "storenofrom";
            this.storenofromDataGridViewTextBoxColumn.HeaderText = "Kothari no.";
            this.storenofromDataGridViewTextBoxColumn.Name = "storenofromDataGridViewTextBoxColumn";
            this.storenofromDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // statusDataGridViewTextBoxColumn1
            // 
            this.statusDataGridViewTextBoxColumn1.DataPropertyName = "status";
            this.statusDataGridViewTextBoxColumn1.HeaderText = "status";
            this.statusDataGridViewTextBoxColumn1.Name = "statusDataGridViewTextBoxColumn1";
            this.statusDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // shopnofromDataGridViewTextBoxColumn1
            // 
            this.shopnofromDataGridViewTextBoxColumn1.DataPropertyName = "shopnofrom";
            this.shopnofromDataGridViewTextBoxColumn1.HeaderText = "shopnofrom";
            this.shopnofromDataGridViewTextBoxColumn1.Name = "shopnofromDataGridViewTextBoxColumn1";
            this.shopnofromDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // shopnotoDataGridViewTextBoxColumn
            // 
            this.shopnotoDataGridViewTextBoxColumn.DataPropertyName = "shopnoto";
            this.shopnotoDataGridViewTextBoxColumn.HeaderText = "shopnoto";
            this.shopnotoDataGridViewTextBoxColumn.Name = "shopnotoDataGridViewTextBoxColumn";
            this.shopnotoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ttotDataGridViewTextBoxColumn
            // 
            this.ttotDataGridViewTextBoxColumn.DataPropertyName = "ttot";
            this.ttotDataGridViewTextBoxColumn.HeaderText = "Total";
            this.ttotDataGridViewTextBoxColumn.Name = "ttotDataGridViewTextBoxColumn";
            this.ttotDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paidDataGridViewTextBoxColumn
            // 
            this.paidDataGridViewTextBoxColumn.DataPropertyName = "paid";
            this.paidDataGridViewTextBoxColumn.HeaderText = "paid";
            this.paidDataGridViewTextBoxColumn.Name = "paidDataGridViewTextBoxColumn";
            this.paidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dueDataGridViewTextBoxColumn
            // 
            this.dueDataGridViewTextBoxColumn.DataPropertyName = "due";
            this.dueDataGridViewTextBoxColumn.HeaderText = "due";
            this.dueDataGridViewTextBoxColumn.Name = "dueDataGridViewTextBoxColumn";
            this.dueDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // storenofromDataGridViewTextBoxColumn1
            // 
            this.storenofromDataGridViewTextBoxColumn1.DataPropertyName = "storenofrom";
            this.storenofromDataGridViewTextBoxColumn1.HeaderText = "Kotharinofrom";
            this.storenofromDataGridViewTextBoxColumn1.Name = "storenofromDataGridViewTextBoxColumn1";
            this.storenofromDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // storenotoDataGridViewTextBoxColumn
            // 
            this.storenotoDataGridViewTextBoxColumn.DataPropertyName = "storenoto";
            this.storenotoDataGridViewTextBoxColumn.HeaderText = "Kotharinoto";
            this.storenotoDataGridViewTextBoxColumn.Name = "storenotoDataGridViewTextBoxColumn";
            this.storenotoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // shopnofromDataGridViewTextBoxColumn2
            // 
            this.shopnofromDataGridViewTextBoxColumn2.DataPropertyName = "shopnofrom";
            this.shopnofromDataGridViewTextBoxColumn2.HeaderText = "shopnofrom";
            this.shopnofromDataGridViewTextBoxColumn2.Name = "shopnofromDataGridViewTextBoxColumn2";
            this.shopnofromDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // shopnotoDataGridViewTextBoxColumn1
            // 
            this.shopnotoDataGridViewTextBoxColumn1.DataPropertyName = "shopnoto";
            this.shopnotoDataGridViewTextBoxColumn1.HeaderText = "shopnoto";
            this.shopnotoDataGridViewTextBoxColumn1.Name = "shopnotoDataGridViewTextBoxColumn1";
            this.shopnotoDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // totalDataGridViewTextBoxColumn
            // 
            this.totalDataGridViewTextBoxColumn.DataPropertyName = "total";
            this.totalDataGridViewTextBoxColumn.HeaderText = "total";
            this.totalDataGridViewTextBoxColumn.Name = "totalDataGridViewTextBoxColumn";
            this.totalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paidDataGridViewTextBoxColumn1
            // 
            this.paidDataGridViewTextBoxColumn1.DataPropertyName = "paid";
            this.paidDataGridViewTextBoxColumn1.HeaderText = "paid";
            this.paidDataGridViewTextBoxColumn1.Name = "paidDataGridViewTextBoxColumn1";
            this.paidDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // storenofromDataGridViewTextBoxColumn2
            // 
            this.storenofromDataGridViewTextBoxColumn2.DataPropertyName = "storenofrom";
            this.storenofromDataGridViewTextBoxColumn2.HeaderText = "Kothari nofrom";
            this.storenofromDataGridViewTextBoxColumn2.Name = "storenofromDataGridViewTextBoxColumn2";
            this.storenofromDataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // storenotoDataGridViewTextBoxColumn1
            // 
            this.storenotoDataGridViewTextBoxColumn1.DataPropertyName = "storenoto";
            this.storenotoDataGridViewTextBoxColumn1.HeaderText = "Kothari noto";
            this.storenotoDataGridViewTextBoxColumn1.Name = "storenotoDataGridViewTextBoxColumn1";
            this.storenotoDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1362, 741);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.radioButton5);
            this.Controls.Add(this.radioButton6);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.radioButton4);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "ग्वालियर व्यापार मेला";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.shopstatusBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.storestatusBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.noduesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.electricityBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.practiceDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private PracticeDataSet2 practiceDataSet2;
        private System.Windows.Forms.BindingSource shopstatusBindingSource;
        private PracticeDataSet2TableAdapters.shopstatusTableAdapter shopstatusTableAdapter;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private PracticeDataSet3 practiceDataSet3;
        private System.Windows.Forms.BindingSource storestatusBindingSource;
        private PracticeDataSet3TableAdapters.storestatusTableAdapter storestatusTableAdapter;
        private System.Windows.Forms.Label label5;
        private PracticeDataSet4 practiceDataSet4;
        private System.Windows.Forms.BindingSource electricityBindingSource;
        private PracticeDataSet4TableAdapters.ElectricityTableAdapter electricityTableAdapter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView4;
        private PracticeDataSet5 practiceDataSet5;
        private System.Windows.Forms.BindingSource noduesBindingSource;
        private PracticeDataSet5TableAdapters.NoduesTableAdapter noduesTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView3;
        private PracticeDataSet6 practiceDataSet6;
        private System.Windows.Forms.BindingSource electricityBindingSource1;
        private PracticeDataSet6TableAdapters.ElectricityTableAdapter electricityTableAdapter1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopnofromDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopnofromDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopnotoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paidDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn storenofromDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn storenotoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopnofromDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn shopnotoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ttotDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn storenofromDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn storenotoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn storenofromDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn1;
    }
}

