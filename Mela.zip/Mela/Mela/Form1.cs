﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
namespace Mela
{
    public partial class Form1 : Form
    {
        public static string set1 = "";
        public static string set2 = "";
        public static string set3 = "";
        public static string set4 = "";
        public static string set5 = "";
        public static string set6 = "";
        public static string set13 = "";
        public static string set14 = "";
        public static int set7 = 0;
        public static int set8 = 0;
        public static int set9 = 0;
        public static int set10 = 0;
        public static int set11 =0 ;
        public static int set12 =0 ;
        DataSet ds = new DataSet();
        DataSet ds1 = new DataSet();
        public Form1()
        {
            Thread t = new Thread(new ThreadStart(splashstart));
            t.Start();
            Thread.Sleep(5000);
            InitializeComponent();
            t.Abort();
        }
        public void splashstart()
        {
            Application.Run(new Form6());

        }
        SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
        private void Form1_Load(object sender, EventArgs e)
        {
            int a = 0;
            textBox5.Text = a.ToString();
            textBox4.Text = a.ToString();
            textBox1.Text = a.ToString();
            textBox3.Text = a.ToString();

            // TODO: This line of code loads data into the 'practiceDataSet6.Electricity' table. You can move, or remove it, as needed.
            this.electricityTableAdapter1.Fill(this.practiceDataSet6.Electricity);
            // TODO: This line of code loads data into the 'practiceDataSet5.Nodues' table. You can move, or remove it, as needed.
            this.noduesTableAdapter.Fill(this.practiceDataSet5.Nodues);
            // TODO: This line of code loads data into the 'practiceDataSet4.Electricity' table. You can move, or remove it, as needed.
            this.electricityTableAdapter.Fill(this.practiceDataSet4.Electricity);
            // TODO: This line of code loads data into the 'practiceDataSet3.storestatus' table. You can move, or remove it, as needed.
            this.storestatusTableAdapter.Fill(this.practiceDataSet3.storestatus);
            try
            {
                // TODO: This line of code loads data into the 'practiceDataSet2.shopstatus' table. You can move, or remove it, as needed.
                this.shopstatusTableAdapter.Fill(this.practiceDataSet2.shopstatus);
                
            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 f2 = new Form3();
            f2.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form4 f2 = new Form4();
            f2.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            admin a = new admin();
            a.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form3 f2 = new Form3();
            f2.Show();
        }

        

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form4 f2 = new Form4();
            f2.Show();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            admin a = new admin();
            a.Show();
        }

        

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from shopstatus where status='Reserved' ", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;


            }
            catch (Exception r)
            {
                MessageBox.Show(r.Message);
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter("select * from shopstatus where status='UnReserved' ", cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;


            }
            catch (Exception r)
            {
                MessageBox.Show(r.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 f1 = new Form5();
            f1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form7 f1 = new Form7();
            f1.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = 0; ;
            int b=0;
            int c=0;
            int d=0;
            int i=0;
            int f=0;


            try
            {
                int a1 = 0;
                int no = int.Parse(textBox1.Text);
                int no1 = int.Parse(textBox3.Text);
                string year = textBox2.Text.TrimStart();
                if (no > 0)
                {

                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();

                    string Name = string.Format("  Select name,fname,address,shopnofrom,shopnoto,blockno,id,storenofrom,storenoto from Registration where shopnofrom={0} and shopnoto={2} and year='{1}' ", no,year,no1);
                    SqlCommand cmd = new SqlCommand(Name, cn);

                    SqlDataReader rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        string name = string.Format(" {0} ", rec.GetValue(0));
                        set1 = name;
                        string fname = string.Format(" {0} ", rec.GetValue(1));
                        set2 = fname;
                        string add = string.Format(" {0} ", rec.GetValue(2));
                        set3 = add;

                        string from = string.Format(" {0} ", rec.GetValue(3));
                        set4 = from;
                        string to = string.Format(" {0} ", rec.GetValue(4));
                        set5 = to;
                        string block = string.Format(" {0} ", rec.GetValue(5));
                        set6 = block;
                        int id = int.Parse(string.Format(" {0} ", rec.GetValue(6)));
                        set11 = id;
                        string store = string.Format(" {0} ", rec.GetValue(7));
                        set13 = store;
                        string store1 = string.Format(" {0} ", rec.GetValue(8));
                        set14 = store1;
                        Search s = new Search();
                        s.Show();
                        rec.Close();
                    }
                    else
                    {
                        rec.Close();
                        MessageBox.Show("no record found");
                    }

                    Name = string.Format("  Select * from Registration where shopnofrom={0} and shopnoto={2} and year='{1}' ", no,year,no1);
                    cmd = new SqlCommand(Name, cn);
                    
                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {
                        
                         a = 1;
                        set7 = a;
                        rec.Close();
                    }
                    else
                    {
                        a = 0;
                        set7 = a;
                        rec.Close();
                    }

                    Name = string.Format("  Select * from Reservation where shopnofrom={0} and shopnoto={2} and year=' {1}' ", no,year,no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        b = 1;
                        set8 = b;
                        rec.Close();
                    }
                    else
                    {
                        b = 0;
                        set8 = b;
                        rec.Close();
                    }

                    /*Name = string.Format("  Select * from Payment where shopnofrom={0} and shopnoto={2} and year='  {1}' ", no,year,no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        c = 1;
                        set9 = c;
                        rec.Close();
                    }
                    else
                    {
                        c = 0;
                        set9 = c;
                        rec.Close();
                    }*/

                    Name = string.Format("  Select * from Extraarea where shopnofrom={0} and shopnoto={2} and year='  {1}' ", no,year,no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        d = 1;
                        set10 = d;
                        rec.Close();
                    }
                    else
                    {
                        d = 0;
                        set10 = d;
                        rec.Close();
                    }

                    Name = string.Format("  Select * from Electricity where shopnofrom={0} and shopnoto={2} and year='{1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        i = 1;
                        set11 = i;
                        rec.Close();
                    }
                    else
                    {
                        i = 0;
                        set11 = i;
                        rec.Close();
                    }
                    Name = string.Format("  Select * from Nodues where shopnofrom={0} and shopnoto={2} and year='  {1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        f = 1;
                        set12 = f;
                        rec.Close();
                    }
                    else
                    {
                        f = 0;
                        set12 = f;
                        rec.Close();
                    }

                }

                }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form8 f = new Form8();
            f.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            int a = 0; ;
            int b = 0;
            int c = 0;
            int d = 0;
            int i = 0;
            int f = 0;


            try
            {
                int a1 = 0;
                int no = int.Parse(textBox5.Text);
                int no1 = int.Parse(textBox4.Text);
                string year = textBox2.Text.TrimStart();
                if (no > 0 && no1>0)
                {

                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();

                    string Name = string.Format("  Select name,fname,address,storenofrom,storenoto,blockno,id,shopnofrom,shopnoto from Registration where storenofrom={0} and storenoto={2} and year='{1}' ", no, year, no1);
                    SqlCommand cmd = new SqlCommand(Name, cn);

                    SqlDataReader rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        string name = string.Format(" {0} ", rec.GetValue(0));
                        set1 = name;
                        string fname = string.Format(" {0} ", rec.GetValue(1));
                        set2 = fname;
                        string add = string.Format(" {0} ", rec.GetValue(2));
                        set3 = add;
                        string store = string.Format(" {0} ", rec.GetValue(3));
                        set13 =store;
                        string store1 = string.Format(" {0} ", rec.GetValue(4));
                        set14 = store1;

                        string block = string.Format(" {0} ", rec.GetValue(5));
                        set6 = block;
                        int id = int.Parse(string.Format(" {0} ", rec.GetValue(6)));
                        set11 = id;
                        string from = string.Format(" {0} ", rec.GetValue(7));
                        set4 = from;
                        string to = string.Format(" {0} ", rec.GetValue(8));
                        set5 = to;
                        Search s = new Search();
                        s.Show();
                        rec.Close();
                    }
                    else
                    {
                        rec.Close();
                        MessageBox.Show("no record found");
                    }

                    Name = string.Format("  Select * from Registration where storenofrom={0} and storenoto={2} and year='{1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        a = 1;
                        set7 = a;
                        rec.Close();
                    }
                    else
                    {
                        a = 0;
                        set7 = a;
                        rec.Close();
                    }

                    Name = string.Format("  Select * from Reservation where storenofrom={0} and storenoto={2} and year=' {1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        b = 1;
                        set8 = b;
                        rec.Close();
                    }
                    else
                    {
                        b = 0;
                        set8 = b;
                        rec.Close();
                    }

                   /* Name = string.Format("  Select * from Payment where storenofrom={0} and storenoto={2} and year='  {1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        c = 1;
                        set9 = c;
                        rec.Close();
                    }
                    else
                    {
                        c = 0;
                        set9 = c;
                        rec.Close();
                    }
                    */
                    Name = string.Format("  Select * from Extraarea where storenofrom={0} and storenoto={2} and year='  {1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        d = 1;
                        set10 = d;
                        rec.Close();
                    }
                    else
                    {
                        d = 0;
                        set10 = d;
                        rec.Close();
                    }

                    Name = string.Format("  Select * from Electricity where storenofrom={0} and storenoto={2} and year='{1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        i = 1;
                        set11 = i;
                        rec.Close();
                    }
                    else
                    {
                        i = 0;
                        set11 = i;
                        rec.Close();
                    }
                    Name = string.Format("  Select * from Nodues where storenofrom={0} and storenoto={2} and year='  {1}' ", no, year, no1);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        f = 1;
                        set12 = f;
                        rec.Close();
                    }
                    else
                    {
                        f = 0;
                        set12 = f;
                        rec.Close();
                    }

                }

            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int a = 0; ;
            int b = 0;
            int c = 0;
            int d = 0;
            int i = 0;
            int f = 0;


            try
            {
                int a1 = 0;
                int no = int.Parse(textBox1.Text);
                int no1 = int.Parse(textBox3.Text);
                int no3 = int.Parse(textBox5.Text);
                int no4 = int.Parse(textBox4.Text);
                string year = textBox2.Text.TrimStart();
                if (no > 0)
                {

                    SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                    cn.Open();

                    string Name = string.Format("  Select name,fname,address,shopnofrom,shopnoto,blockno,id,storenofrom,storenoto from Registration where shopnofrom={0} and shopnoto={2} and year='{1}' and storenofrom={3} and storenoto={4}", no, year, no1,no3,no4);
                    SqlCommand cmd = new SqlCommand(Name, cn);

                    SqlDataReader rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        string name = string.Format(" {0} ", rec.GetValue(0));
                        set1 = name;
                        string fname = string.Format(" {0} ", rec.GetValue(1));
                        set2 = fname;
                        string add = string.Format(" {0} ", rec.GetValue(2));
                        set3 = add;

                        string from = string.Format(" {0} ", rec.GetValue(3));
                        set4 = from;
                        string to = string.Format(" {0} ", rec.GetValue(4));
                        set5 = to;
                        string block = string.Format(" {0} ", rec.GetValue(5));
                        set6 = block;
                        int id = int.Parse(string.Format(" {0} ", rec.GetValue(6)));
                        set11 = id;
                        int store = int.Parse(string.Format(" {0} ", rec.GetValue(7)));
                        set13 = store.ToString();
                        int store1 = int.Parse(string.Format(" {0} ", rec.GetValue(8)));
                        set14 = store1.ToString();
                        Search s = new Search();
                        s.Show();
                        rec.Close();
                    }
                    else
                    {
                        rec.Close();
                        MessageBox.Show("no record found");
                    }

                    Name = string.Format("  Select * from Registration where shopnofrom={0} and shopnoto={2} and year='{1}' and storenofrom={3} and storenoto={4} ", no, year, no1,no3,no4);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        a = 1;
                        set7 = a;
                        rec.Close();
                    }
                    else
                    {
                        a = 0;
                        set7 = a;
                        rec.Close();
                    }

                    Name = string.Format("  Select * from Reservation where shopnofrom={0} and shopnoto={2} and year=' {1}' and storenofrom={3} and storenoto={4} ", no, year, no1,no3,no4);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        b = 1;
                        set8 = b;
                        rec.Close();
                    }
                    else
                    {
                        b = 0;
                        set8 = b;
                        rec.Close();
                    }

                   /* Name = string.Format("  Select * from Payment where shopnofrom={0} and shopnoto={2} and year='  {1}' and storenofrom={3} and storenoto={4} ", no, year, no1,no3,no4);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        c = 1;
                        set9 = c;
                        rec.Close();
                    }
                    else
                    {
                        c = 0;
                        set9 = c;
                        rec.Close();
                    }*/

                    Name = string.Format("  Select * from Extraarea where shopnofrom={0} and shopnoto={2} and year='  {1}' and storenofrom={3} and storenoto={4} ", no, year, no1, no3, no4);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        d = 1;
                        set10 = d;
                        rec.Close();
                    }
                    else
                    {
                        d = 0;
                        set10 = d;
                        rec.Close();
                    }

                    Name = string.Format("  Select * from Electricity where shopnofrom={0} and shopnoto={2} and year='{1}' and storenofrom={3} and storenoto={4} ", no, year, no1, no3, no4);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        i = 1;
                        set11 = i;
                        rec.Close();
                    }
                    else
                    {
                        i = 0;
                        set11 = i;
                        rec.Close();
                    }
                    Name = string.Format("  Select * from Nodues where shopnofrom={0} and shopnoto={2} and year='  {1}' and storenofrom={3} and storenoto={4} ", no, year, no1, no3, no4);
                    cmd = new SqlCommand(Name, cn);

                    rec = cmd.ExecuteReader();
                    if (rec.Read())
                    {

                        f = 1;
                        set12 = f;
                        rec.Close();
                    }
                    else
                    {
                        f = 0;
                        set12 = f;
                        rec.Close();
                    }

                }

            }
            catch (Exception g)
            {
                MessageBox.Show(g.Message);
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
           
                SqlDataAdapter sda1 = new SqlDataAdapter("select * from storestatus where status='Reserved' ", cn);
                DataTable dt1 = new DataTable();
                sda1.Fill(dt1);
                dataGridView2.DataSource = dt1;



            }
            catch (Exception r)
            {
                MessageBox.Show(r.Message);
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter sda1 = new SqlDataAdapter("select * from storestatus where status='UnReserved' ", cn);
                DataTable dt1 = new DataTable();
                sda1.Fill(dt1);
                dataGridView2.DataSource = dt1;


            }
            catch (Exception r)
            {
                MessageBox.Show(r.Message);
            }
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            
            try
            {
                string y =textBox6.Text;
               string query = string.Format("select * from Nodues where year='  {0}'",y);
                SqlDataAdapter sda = new SqlDataAdapter(query, cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView4.DataSource = dt;


            }
            catch (Exception r)
            {
                MessageBox.Show("enter correct session");
            }
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                string y = textBox6.Text;
                string query = string.Format("select * from Electricity where year='{0}' and due=0", y);
                SqlDataAdapter sda = new SqlDataAdapter(query, cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView3.DataSource = dt;


            }
            catch (Exception r)
            {
                MessageBox.Show("enter correct session");
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                string y = textBox6.Text;
                string query = string.Format("select * from Electricity where year='{0}' and due!=0", y);
                SqlDataAdapter sda = new SqlDataAdapter(query, cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView3.DataSource = dt;


            }
            catch (Exception r)
            {
                MessageBox.Show("enter correct session");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {

            try
            {
                string y = textBox6.Text;
                string query = string.Format("select * from Nodues where year='  {0}'", y);
                SqlDataAdapter sda = new SqlDataAdapter(query, cn);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView4.DataSource = dt;


            }
            catch (Exception r)
            {
                MessageBox.Show("enter correct session");
            }
        }
    }
}
