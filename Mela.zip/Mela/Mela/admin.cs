﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Mela
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            long pass = long.Parse(textBox2.Text);
            bool st = checking(user, pass);
            if (st==true)
            {
                admin1 a = new admin1();
                a.Show();

            }
            else
            {

                MessageBox.Show("Wrong username/password");
            }
            this.Hide();
        }
        public static bool checking(string u,long i)
        {
            
            try
            {
              
                SqlConnection cn = new SqlConnection("server=Localhost;initial catalog=Practice;trusted_connection=true");
                cn.Open();
                String Query = String.Format(" select * from admin where username='{0}'and password={1} ",u,i);
                bool st = exe(cn, Query);
                return st;
            }
            catch (Exception e)
            {
                
                return false;
            }
        }
        public static bool exe(SqlConnection cn, String Query)
        {
            try
            {
                
                SqlCommand cmd = new SqlCommand(Query, cn);
                SqlDataReader rec = cmd.ExecuteReader();
                if (rec.Read())
                { return true; }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                return false;
            }
        }
            
    }
}
